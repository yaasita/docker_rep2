<?php
/*
    p2 -  ���j���[ �g�їp
*/

//080825iphone�p���C�u�����ǉ�
require_once './conf/conf.inc.php';
require_once P2_LIB_DIR . '/BrdCtl.php';
require_once P2_IPHONE_LIB_DIR . '/ShowBrdMenuK.php';

$_login->authorize(); // ���[�U�F��

//==============================================================
// �ϐ��ݒ�
//==============================================================
$_conf['ktai'] = 1;
$brd_menus = array();
$GLOBALS['menu_show_ita_num'] = 0;

BrdCtl::parseWord(); // set $GLOBALS['word']

//============================================================
// ����ȑO����
//============================================================
// ���C�ɔ̒ǉ��E�폜
if (isset($_GET['setfavita'])) {
    if (!isset($_REQUEST['csrfid']) || !P2Util::checkCsrfId($_REQUEST['csrfid'])) {
        p2die('�s���ȃN�G���[�ł��iCSRF�΍�j');
    }
    require_once P2_LIB_DIR . '/setFavIta.func.php';
    setFavIta();
}

//================================================================
// ���C��
//================================================================
$aShowBrdMenuK = new ShowBrdMenuK;

//============================================================
// �w�b�_HTML��\��
//============================================================

$get['view'] = isset($_GET['view']) ? $_GET['view'] : null;

$ptitle = _getPtitle(geti($_GET['view']), geti($_GET['cateid']));

P2View::printDoctypeTag();
?>
<html>
<head>
<?php P2View::printStyleTagImportIuiCss(); ?>
<script type="text/javascript"> 
<!-- 
window.onload = function() { 
setTimeout(scrollTo, 100, 0, 1); 
} 
</script> 
<?php
P2View::printExtraHeadersHtml();
?>

<title><?php eh($ptitle); ?></title>
</head>
<body class="menu_i">
<?php $index_uri = UriUtil::buildQueryUri('index.php', array(UA::getQueryKey() => UA::getQueryValue())); ?>
<p><a id="backButton" class="tbutton" href="<?php eh($index_uri); ?>">TOP</a></p>

<div class="toolbar"><h1 class="pageTitle"><?php eh($ptitle); ?></h1></div>
<?php
P2Util::printInfoHtml();


// ���C�ɔ�HTML�\������
if ($get['view'] == 'favita') {
    $aShowBrdMenuK->printFavItaHtml();

// ����ȊO�Ȃ�brd�ǂݍ���
} else {
    $brd_menus = BrdCtl::readBrdMenus();
}

// �����t�H�[����HTML�\��
if ($get['view'] != 'favita' && $get['view'] != 'rss' && empty($_GET['cateid'])) {
    echo '<div class="panel itaKensaku"><filedset>';
    echo BrdCtl::getMenuKSearchFormHtml();
    echo '</filedset></div>';
}

//===========================================================
// �������ʂ�HTML�\��
//===========================================================

$modori_url_ht = '';

// {{{ �������[�h�������

if (strlen($GLOBALS['word'])) {

    ?><div class="panel"><h2>
    <?php
    if ($GLOBALS['ita_mikke']['num']) {
        printf('"%s" %dhit!', hs($GLOBALS['word']), $GLOBALS['ita_mikke']['num']);
    }
    ?></h2></div><?php
    
    // �����������ĕ\������
    if ($brd_menus) {
        foreach ($brd_menus as $a_brd_menu) {
            $aShowBrdMenuK->printItaSearch($a_brd_menu->categories);
        }
    }

    if (!$GLOBALS['ita_mikke']['num']) {
        P2Util::pushInfoHtml(sprintf('"%s"���܂ޔ͌�����܂���ł����B', hs($GLOBALS['word'])));
    }
    $atag = P2View::tagA(
        UriUtil::buildQueryUri($_conf['menu_k_php'],
            array(
                'view' => 'cate',
                'nr'   => '1',
                UA::getQueryKey() => UA::getQueryValue()
            )
        ),
        hs('��ؽ�')
    );
    $modori_url_ht = '<div>' . $atag . '</div>';
}

// }}}

// �J�e�S�����X�g��HTML�\��
if ($get['view'] == 'cate' or isset($_REQUEST['word']) && !strlen($GLOBALS['word'])) {
    //echo "��ؽ�{$hr}";
    if ($brd_menus) {
        foreach ($brd_menus as $a_brd_menu) {
            $aShowBrdMenuK->printCate($a_brd_menu->categories);
        }
    }
}

// �w�肵���J�e�S���̔�HTML�\��
if (isset($_GET['cateid'])) {
    if ($brd_menus) {
        foreach ($brd_menus as $a_brd_menu) {
            $aShowBrdMenuK->printIta($a_brd_menu->categories);
        }
    }
    $modori_url_ht = P2View::tagA(
        UriUtil::buildQueryUri($_conf['menu_k_php'],
            array('view' => 'cate', 'nr' => '1', UA::getQueryKey() => UA::getQueryValue())
        ),
        '��ؽ�'
    ) . '<br>';
}

P2Util::printInfoHtml();

// �t�b�^��HTML�\��
echo geti($GLOBALS['list_navi_ht']);
?>

</body></html>
<?php

exit;


//==============================================================================
// �֐��i���̃t�@�C�����ł̂ݗ��p�j
//==============================================================================
/**
 * @return  string
 */
function _getPtitle($view, $cateid)
{
    $ptitle = '';
    if ($view == 'favita') {
        $ptitle = '���C�ɔ�';
    } elseif ($view == 'cate'){
        $ptitle = '���X�g';
    } elseif (isset($cateid)) {
        $ptitle = '���X�g';
    } else {
        $ptitle = 'rep2iPhone'; // '��޷��p2';
        if (UA::isAndroidWebKit()) {
            $ptitle = 'rep2Android';
        }
    }
    return $ptitle;
}