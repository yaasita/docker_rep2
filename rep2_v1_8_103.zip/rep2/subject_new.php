<?php
/*
    �i// p2 -  �X���b�h�T�u�W�F�N�g�\���X�N���v�g�j
    �i// �t���[��������ʁA�E�㕔���j

    ���̃X�N���v�g�͕ϑ��I�Binclude�ŌĂяo���ė��p���Ă���B��x�̎��s�ŕ�����Ăяo�����B
    ����������A���j���[�ŐV������m�邽�߂Ɏg�p���Ă��� // $shinchaku_num, $_newthre_num ���Z�b�g
    �i�ϐ��̃X�R�[�v�͕������Ƃ���j

    subject.php �ƌZ��Ȃ̂ňꏏ�ɖʓ|���݂�

    $host, $bbs, $spmode �����炩���ߏ������Ă���
*/

$shinchaku_num = 0;
$_newthre_num  = 0;

//require_once './conf/conf.inc.php';
require_once P2_LIB_DIR . '/ThreadList.php';
require_once P2_LIB_DIR . '/Thread.php';

require_once P2_LIB_DIR . '/subject.funcs.php';

if (!empty($aThreadList)) {
    unset($aThreadList);
}

//============================================================
// �ϐ��ݒ�
//============================================================

if (isset($_GET['from'])) { $sb_disp_from = $_GET['from']; }
if (isset($_POST['from'])) { $sb_disp_from = $_POST['from']; }
if (!isset($sb_disp_from)) { $sb_disp_from = 1; }

// p2_setting �ݒ�
if ($spmode) {
    $p2_setting_txt = $_conf['pref_dir'] . '/p2_setting_' . $spmode . '.txt';
} else {
    $idx_bbs_dir_s = P2Util::idxDirOfHostBbs($host, $bbs);

    $p2_setting_txt = $idx_bbs_dir_s . "p2_setting.txt";
    $sb_keys_b_txt  = $idx_bbs_dir_s . "p2_sb_keys_b.txt";
    $sb_keys_txt    = $idx_bbs_dir_s . "p2_sb_keys.txt";

    if (!empty($_REQUEST['norefresh']) || !empty($_REQUEST['word'])) {
        if ($prepre_sb_cont = @file_get_contents($sb_keys_b_txt)) {
            $prepre_sb_keys = unserialize($prepre_sb_cont);
        }
    } else {
        if ($pre_sb_cont = @file_get_contents($sb_keys_txt)) {
            $pre_sb_keys = unserialize($pre_sb_cont);
        }
    }
}

// p2_setting �ǂݍ���
$p2_setting = sbLoadP2SettingTxt($p2_setting_txt);

$p2_setting = sbSetP2SettingWithQuery($p2_setting);

if (isset($_GET['sb_view']))  { $sb_view = $_GET['sb_view']; }
if (isset($_POST['sb_view'])) { $sb_view = $_POST['sb_view']; }
if (empty($sb_view)) {$sb_view = "normal";}

// �\���X���b�h�� ====================================
$threads_num_max = 2000;

if (!$spmode || $spmode=="news") {
    $threads_num = $p2_setting['viewnum'];
    
} elseif ($spmode == "recent") {
    $threads_num = $_conf['rct_rec_num'];
    
} elseif ($spmode == "res_hist") {
    $threads_num = $_conf['res_hist_rec_num'];
    
} else {
    $threads_num = 2000;
}

if ($p2_setting['viewnum'] == "all") { $threads_num = $threads_num_max; }
elseif ($sb_view == "shinchaku") { $threads_num = $threads_num_max; }
elseif ($sb_view == "edit") { $threads_num = $threads_num_max; }
elseif (isset($_GET['word'])) { $threads_num = $threads_num_max; }
elseif ($_conf['ktai']) { $threads_num = $threads_num_max; }


//============================================================
// ���C��
//============================================================

$aThreadList = new ThreadList;

// �ƃ��[�h�̃Z�b�g ===================================
if ($spmode) {
    if ($spmode == "taborn" or $spmode == "soko") {
        $aThreadList->setIta($host, $bbs, P2Util::getItaName($host, $bbs));
    }
    $aThreadList->setSpMode($spmode);
} else {
    // if (!$p2_setting['itaj']) { $p2_setting['itaj'] = P2Util::getItaName($host, $bbs); }
    $aThreadList->setIta($host, $bbs, isset($p2_setting['itaj']) ? $p2_setting['itaj'] : null);
    
    // �X���b�h���ځ[�񃊃X�g�Ǎ�
    $ta_keys = P2Util::getThreadAbornKeys($aThreadList->host, $aThreadList->bbs);
    //$ta_num = sizeOf($ta_keys);
}

// �\�[�X���X�g�Ǎ�
$lines = $aThreadList->readList();

// ���C�ɃX�����X�g �Ǎ�
if (file_exists($_conf['favlist_file'])) {
    $favlines = file($_conf['favlist_file']);
    if (is_array($favlines)) {
        foreach ($favlines as $l) {
            $data = explode('<>', rtrim($l));
            $fav_keys[ $data[1] ] = true;
        }
    }
}

//============================================================
// ���ꂼ��̍s���
//============================================================

$nowtime  = time();
$linesize = sizeof($lines);

for ($x = 0; $x < $linesize ; $x++) {

    $l = rtrim($lines[$x]);
    
    $aThread = new Thread;
    
    if ($aThreadList->spmode != "taborn" and $aThreadList->spmode != "soko") {
        $aThread->torder = $x + 1;
    }

    // ���C������X���b�h�f�[�^��ǂݍ���ŃZ�b�g
    $aThread->setThreadInfoFromLineWithThreadList($l, $aThreadList);
    
    // host��bbs��key���s���Ȃ�X�L�b�v
    if (!($aThread->host && $aThread->bbs && $aThread->key)) {
        unset($aThread);
        continue;
    } 
    
    // {{{ �V�������ǂ���(for subject)
    
    if (!$aThreadList->spmode) {
        if (!empty($_REQUEST['norefresh']) || !empty($_REQUEST['word'])) {
            if (empty($prepre_sb_keys[$aThread->key])) {
                $aThread->new = true;
            }
        } else {
            if (empty($pre_sb_keys[$aThread->key])) {
                $aThread->new = true;
            }
            $subject_keys[$aThread->key] = true;
        }
    }
    
    // }}}
    // {{{ �X���b�h���ځ[��`�F�b�N
    
    if ($aThreadList->spmode != 'taborn' and !empty($ta_keys[$aThread->key])) { 
            unset($ta_keys[$aThread->key]);
            continue; // ���ځ[��X���̓X�L�b�v
    }

    $aThread->setThreadPathInfo($aThread->host, $aThread->bbs, $aThread->key);
    $aThread->getThreadInfoFromIdx(); // �����X���b�h�f�[�^��idx����擾

    // }}}
    // {{{ favlist�`�F�b�N
    
    !empty($debug) && $profiler->enterSection('favlist_check');
    // if ($x <= $threads_num) {
        if ($aThreadList->spmode != 'taborn' and !empty($fav_keys[$aThread->key])) {
            $aThread->fav = 1;
            unset($fav_keys[$aThread->key]);
        }
    // }
    !empty($debug) && $profiler->leaveSection('favlist_check');
    
    // }}}
    
    // �� spmode(�a������Anews������)�Ȃ� ====================================
    if ($aThreadList->spmode && $aThreadList->spmode!="news" && $sb_view!="edit") { 
        
        // {{{ subject.txt ����DL�Ȃ痎�Ƃ��ăf�[�^��z��Ɋi�[����
        
        if (empty($subject_txts["$aThread->host/$aThread->bbs"])) {

            require_once P2_LIB_DIR . '/SubjectTxt.php';
            $aSubjectTxt = new SubjectTxt($aThread->host, $aThread->bbs);
            
            !empty($debug) && $profiler->enterSection('subthre_read'); //
            if ($aThreadList->spmode == "soko" or $aThreadList->spmode == "taborn") {

                if (is_array($aSubjectTxt->subject_lines)) {
                    $it = 1;
                    foreach ($aSubjectTxt->subject_lines as $asbl) {
                        if (preg_match("/^([0-9]+)\.(dat|cgi)(,|<>)(.+) ?(\(|�i)([0-9]+)(\)|�j)/", $asbl, $matches)) {
                            $akey = $matches[1];
                            $subject_txts["$aThread->host/$aThread->bbs"][$akey]['ttitle'] = rtrim($matches[4]);
                            $subject_txts["$aThread->host/$aThread->bbs"][$akey]['rescount'] = $matches[6];
                            $subject_txts["$aThread->host/$aThread->bbs"][$akey]['torder'] = $it;
                        }
                        $it++;
                    }
                }
                
            } else {
                $subject_txts["$aThread->host/$aThread->bbs"] = $aSubjectTxt->subject_lines;
                
            }
            !empty($debug) && $profiler->leaveSection('subthre_read');//
        }
        
        // }}}
        
        !empty($debug) && $profiler->enterSection('subthre_check');//
        // ���X�����擾 =============================
        if ($aThreadList->spmode == "soko" or $aThreadList->spmode == "taborn") {
        
            if ($subject_txts[$aThread->host.'/'.$aThread->bbs][$aThread->key]) {
            
                // �q�ɂ̓I�����C�����܂܂Ȃ�
                if ($aThreadList->spmode == "soko") {
                    !empty($debug) && $profiler->leaveSection('subthre_check'); //
                    unset($aThread);
                    continue;
                } elseif ($aThreadList->spmode == "taborn") {
                    // subject.txt ����X�����擾
                    // $aThread->setThreadInfoFromSubjectTxtLine($l);
                    $aThread->isonline = true;
                    $ttitle = $subject_txts["$aThread->host/$aThread->bbs"][$aThread->key]['ttitle'];
                    $aThread->setTtitle($ttitle);
                    $aThread->rescount = $subject_txts["$aThread->host/$aThread->bbs"][$aThread->key]['rescount'];
                    if ($aThread->readnum) {
                        $aThread->unum = $aThread->rescount - $aThread->readnum;
                        // machi bbs ��sage��subject�̍X�V���s���Ȃ������Ȃ̂Œ������Ă���
                        if ($aThread->unum < 0) { $aThread->unum = 0; }
                    }
                    $aThread->torder = $subject_txts["$aThread->host/$aThread->bbs"][$aThread->key]['torder'];
                }

            }
            
        } else {
        
            if ($subject_txts[$aThread->host.'/'.$aThread->bbs]) {
                $it = 1;
                foreach ($subject_txts[$aThread->host.'/'.$aThread->bbs] as $l) {
                    if (@preg_match("/^{$aThread->key}/", $l)) {
                        // subject.txt ����X�����擾
                        $aThread->setThreadInfoFromSubjectTxtLine($l);
                        break;
                    }
                    $it++;
                }
            }
        
        }
        !empty($debug) && $profiler->leaveSection('subthre_check'); //
        
        if ($aThreadList->spmode == 'taborn') {
            if (!$aThread->torder) { $aThread->torder = '-'; }
        }

        
        // �V���̂�(for spmode)
        if ($sb_view == 'shinchaku' and !$_GET['word']) { 
            if ($aThread->unum < 1) {
                unset($aThread);
                continue;
            }
        }
    }
    
    // subject����rescount�����Ȃ������ꍇ�́Agotnum�𗘗p����B
    if ((!$aThread->rescount) and $aThread->gotnum) {
        $aThread->rescount = $aThread->gotnum;
    }
    
    if (!$aThread->ttitle_ht) {
        $aThread->ttitle_ht = $aThread->ttitle;
    }
    
    if ($aThread->unum > 0) { // �V������
        $shinchaku_num += $aThread->unum; // �V����set
    } elseif ($aThread->fav) { // ���C�ɃX��
        ;
    } elseif ($aThread->new) { // �V�K�X��
        $_newthre_num++; // ��ShowBrdMenuPc.php
    } else {
        // �g�тƃj���[�X�`�F�b�N�ȊO��
        if ($_conf['ktai'] or $spmode != "news") {
            // �w�萔���z���Ă�����J�b�g
            if($x >= $threads_num){
                unset($aThread);
                continue;
            }
        }
    }
    
    /*
    // �V���\�[�g�̕֋X�� unum ���Z�b�g����
    if (!isset($aThread->unum)) {
        if ($aThreadList->spmode == "recent" or $aThreadList->spmode == "res_hist" or $aThreadList->spmode == "taborn") {
            $aThread->unum = -0.1;
        } else {
            $aThread->unum = $_conf['sort_zero_adjust'];
        }
    }
    */
    
    // �����̃Z�b�g
    $aThread->setDayRes($nowtime);
    
    /*
    // ������set
    if ($aThread->isonline) { $online_num++; }
    
    // ���X�g�ɒǉ�
    $aThreadList->addThread($aThread);

    */
    unset($aThread);
    
}

// $shinchaku_num


/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
