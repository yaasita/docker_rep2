<?php

/**
 * �N�G���[����t�B���^���[�h���Z�b�g����
 *
 * @access  public
 * @return  void
 */
function sbSetFilterWord()
{
    global $_conf;
    
    $GLOBALS['sb_filter'] = array();
    $GLOBALS['sb_filter']['method'] = null;
    
    $GLOBALS['word'] = null;
    $GLOBALS['word_fm'] = null;
    $GLOBALS['wakati_word'] = null;

    // �u�X�V�v�ł͂Ȃ��āA�����w�肪����΁A�������[�h���Z�b�g����
    if (empty($_REQUEST['submit_refresh']) or !empty($_REQUEST['submit_kensaku'])) {

        if (isset($_GET['word'])) {
            $GLOBALS['word'] = $_GET['word'];
        } elseif (isset($_POST['word'])) {
            $GLOBALS['word'] = $_POST['word'];
        }
    
        if (isset($_GET['method'])) {
            $GLOBALS['sb_filter']['method'] = $_GET['method'];
        } elseif (isset($_POST['method'])) {
            $GLOBALS['sb_filter']['method'] = $_POST['method'];
        }

        if (isset($GLOBALS['sb_filter']['method']) and $GLOBALS['sb_filter']['method'] == 'similar') {
            $GLOBALS['wakati_word'] = $GLOBALS['word'];
            $GLOBALS['wakati_words'] = _wakati($GLOBALS['word']);
        
            if (!$GLOBALS['wakati_words']) {
                unset($GLOBALS['wakati_word'], $GLOBALS['wakati_words']);
            } else {
                require_once P2_LIB_DIR . '/StrCtl.php';
                $wakati_words2 = array_filter($GLOBALS['wakati_words'], '_wakatiFilter');
            
                if (!$wakati_words2) {
                    $GLOBALS['wakati_hl_regex'] = $GLOBALS['wakati_word'];
                } else {
                    rsort($wakati_words2, SORT_STRING);
                    $GLOBALS['wakati_hl_regex'] = implode(' ', $wakati_words2);
                    $GLOBALS['wakati_hl_regex'] = mb_convert_encoding($GLOBALS['wakati_hl_regex'], 'SJIS-win', 'UTF-8');
                }
            
                $GLOBALS['wakati_hl_regex'] = StrCtl::wordForMatch($GLOBALS['wakati_hl_regex'], 'or');
                $GLOBALS['wakati_hl_regex'] = str_replace(' ', '|', $GLOBALS['wakati_hl_regex']);
                $GLOBALS['wakati_length'] = mb_strlen($GLOBALS['wakati_word'], 'SJIS-win');
                $GLOBALS['wakati_score'] = _getSbScore($GLOBALS['wakati_words'], $GLOBALS['wakati_length']);
            
                if (!isset($_conf['expack.min_similarity'])) {
                    $_conf['expack.min_similarity'] = 0.05;
                } elseif ($_conf['expack.min_similarity'] > 1) {
                    $_conf['expack.min_similarity'] /= 100;
                }
                if (count($GLOBALS['wakati_words']) == 1) {
                    $_conf['expack.min_similarity'] /= 100;
                }
                $_conf['expack.min_similarity'] = (float) $_conf['expack.min_similarity'];
            }
            $GLOBALS['word'] = '';
        
        } elseif (preg_match('/^\.+$/', $GLOBALS['word'])) {
            $GLOBALS['word'] = '';
        }
    
        if (strlen($GLOBALS['word']))  {
        
            // �f�t�H���g�I�v�V����
            // $GLOBALS['sb_filter'] �� global @see sb_print.inc.php
            if (!$GLOBALS['sb_filter']['method']) {
                $GLOBALS['sb_filter']['method'] = 'or';
            }
            
            require_once P2_LIB_DIR . '/StrCtl.php';
            $GLOBALS['word_fm'] = StrCtl::wordForMatch($GLOBALS['word'], $GLOBALS['sb_filter']['method']);
            if ($GLOBALS['sb_filter']['method'] != 'just') {
                if (P2_MBREGEX_AVAILABLE == 1) {
                    $GLOBALS['words_fm'] = mb_split('\s+', $GLOBALS['word_fm']);
                    $GLOBALS['word_fm'] = mb_ereg_replace('\s+', '|', $GLOBALS['word_fm']);
                } else {
                    $GLOBALS['words_fm'] = preg_split('/\s+/', $GLOBALS['word_fm']);
                    $GLOBALS['word_fm'] = preg_replace('/\s+/', '|', $GLOBALS['word_fm']);
                }
            }
        }
    }
}

/**
 * @return  array
 */
function sbLoadP2SettingTxt($p2_setting_txt)
{
    $p2_setting = array();
    if ($p2_setting_cont = @file_get_contents($p2_setting_txt)) {
        $p2_setting = unserialize($p2_setting_cont);
    }
    
    !isset($p2_setting['viewnum']) and $p2_setting['viewnum'] = null;
    !isset($p2_setting['sort'])    and $p2_setting['sort']    = null;
    !isset($p2_setting['itaj'])    and $p2_setting['itaj']    = null;
    
    return $p2_setting;
}

/**
 * @return  array
 */
function sbSetP2SettingWithQuery($p2_setting)
{
    global $_conf;
    
    isset($_GET['viewnum'])  and $p2_setting['viewnum'] = $_GET['viewnum'];
    isset($_POST['viewnum']) and $p2_setting['viewnum'] = $_POST['viewnum'];
    
    if (!isset($p2_setting['viewnum'])) {
        $p2_setting['viewnum'] = $_conf['display_threads_num']; // �f�t�H���g�l
    }

    if (isset($_GET['itaj_en'])) {
        $p2_setting['itaj'] = base64_decode($_GET['itaj_en']);
    }
    return $p2_setting;
}


/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
