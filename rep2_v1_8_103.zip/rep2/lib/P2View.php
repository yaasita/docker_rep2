<?php
/**
 * @created  2008/09/17
 */
class P2View
{
    /**
     * @return  void  HTML�o��
     */
    function printStyleTagImportIuiCss()
    {
?><style type="text/css" media="screen">
<?php if (UA::isWindowsPhoneIEMobile()) { ?>
@import "./iui/iui_wpie.css";
<?php } ?>
@import "./iui/smartphone.css?20140423";
@import "./iui/iui.css?20140423";
</style>
<?php
    }
    
    /**
     * �V���܂Ƃߓǂ݂̃L���b�V�������NHTML��Ԃ�
     *
     * @access  public
     * @return  string  HTML
     */
    function getMatomeCacheLinksHtml()
    {
        $html = '';
        if ($links = P2Util::getMatomeCacheLinks()) {
            if (UA::isIPhoneGroup()) {
                $html .= '<ul><li class="group">�V���܂Ƃߓǂ݂̑O��L���b�V��</li></ul>';
                $html .= '<div class="panel"><filedset>' . implode('<br>', $links)  .'</fildset></div>'. "\n";
            } else {
                $html .= '<p>�V���܂Ƃߓǂ݂̑O��L���b�V����\��<br>' . implode('<br>', $links) . '</p>' . "\n";
            }
        }
        return $html;
    }
    
    /**
     * 2008/09/28 $_conf['k_to_index_ht'] ��p�~���āA������𗘗p����
     *
     * @static
     * @access  public
     * @return  string
     */
    function getBackToIndexKATag()
    {
        global $_conf;
        
        $accessKeyValue = '0';
        
        return P2View::tagA(
            UriUtil::buildQueryUri('index.php',
                array(UA::getQueryKey() => UA::getQueryValue())
            ),
            hs($accessKeyValue . '.TOP'),
            array($_conf['accesskey_for_k'] => $accessKeyValue)
        );
    }
    
    /**
     * @static
     * @access  public
     * @return  string
     */
    function getInputHiddenKTag()
    {
        if (null === $v = UA::getQueryValue()) {
            return '';
        }
        return sprintf('<input type="hidden" name="%s" value="%s">', hs(UA::getQueryKey()), hs($v));
    }
    
    /**
     * HTML�^�O <a href="$url">$html</a> �𐶐�����
     *
     * @static
     * @access  public
     * @param   string  $url   ������ htmlspecialchars() �����B
     *                  2007/10/04 http_build_query() �� �Z�p���[�^�Ƃ��� arg_separator.output �̐ݒ�l���Q�Ƃ��邪�A
     *                  PHP5.1.2��������Ŏw��ł���悤�ɂȂ����̂ŁA������htmlspecialchars()��������悤�ɕύX�����B
     *                  PEAR��compat�̂́A�܂���O���������Ȃ��悤���B�B�I
     * @param   string  $html  �����N�������HTML�B������ł���Ύ蓮�� htmlspecialchars() ���Ă������ƁB
     * @param   array   $attr  a�v�f�̒ǉ������B������ htmlspecialchars() ����������ikey���O�̂��߁j
     * @return  string
     */
    function tagA($url, $html = null, $attr = array())
    {
        $url_hs = hs($url);
        
        $attr_html = '';
        if (is_array($attr)) {
            foreach ($attr as $k => $v) {
                if (strlen($v)) {
                    $attr_html .= ' ' . hs($k) . '="' . hs($v) . '"';
                }
            }
        }
        $html = is_null($html) ? $url_hs : $html;
        
        return '<a href="' . $url_hs . "\"{$attr_html}>" . $html . '</a>';
    }
    
    /**
     * @static
     * @access  public
     * @return  void  HTML�^�O�o��
     */
    function printDoctypeTag()
    {
        $ie_strict = false;
        if (UA::isPC() || UA::isIPhoneGroup()) {
            if ($ie_strict) {
            ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<?php
            } else {
        ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php
            }
        }
    }
    
    /**
     * @static
     * @access  public
     * @return  string
     */
    function getBodyAttrK()
    {
        global $STYLE;
        
        if (!UA::isK()) {
            return '';
        }
        
        $body_at = '';
        if (!empty($STYLE['k_bgcolor'])) {
            $body_at .= ' bgcolor="' . hs($STYLE['k_bgcolor']) . '"';
        }
        if (!empty($STYLE['k_color'])) {
            $body_at .= ' text="' . hs($STYLE['k_color']) . '"';
        }
        if (!empty($STYLE['k_acolor'])) {
            $body_at .= ' link="' . hs($STYLE['k_acolor']) . '"';
        }
        if (!empty($STYLE['k_acolor_v'])) {
            $body_at .= ' vlink="' . hs($STYLE['k_acolor_v']) . '"';
        }
        return $body_at;
    }
    
    /**
     * @static
     * @access  public
     * @return  string
     */
    function getHrHtmlK()
    {
        global $STYLE;
        
        $hr = '<hr>';
        
        if (!UA::isK() || UA::isIPhoneGroup()) {
            return $hr;
        }
        
        if (!empty($STYLE['k_color'])) {
            $hr = '<hr color="' . hs($STYLE['k_color']) . '">';
        }
        return $hr;
    }
    
    /**
     * @static
     * @access  public
     * @return  void  HTML�o��
     */
    function printIncludeCssHtml($css)
    {
        global $_conf, $_login;

        $href = UriUtil::buildQueryUri('css.php',
            array(
                'css'  => $css,
                'user' => $user,
                'skin' => $_conf['skin'],
                'd' => '130612' // �L���b�V������X�V�p
            )
        );
        ?><link rel="stylesheet" type="text/css" href="<?php eh($href); ?>"><?php
    }
    
    /**
     * @static
     * @access  public
     * @return  void  HTML�o��
     */
    function printExtraHeadersHtml($frameset = false)
    {
        P2View::printHeadMetasHtml($frameset);
    }
    
    /**
     * @static
     * @access  public
     * @return  void  HTML�o��
     */
    function printHeadMetasHtml($frameset = false)
    {
        $metas = array(
            array(
                'http-equiv' => 'Content-Type',
                'content'    => 'text/html; charset=Shift_JIS'
            ),
            array(
                'name'    => 'ROBOTS',
                'content' => 'NOINDEX, NOFOLLOW'
            ),
        );
        /*
        // �ȗ�
        if (UA::isPC() || UA::isIPhoneGroup()) {
            $metas[] = array(
                'http-equiv' => 'Content-Style-Type',
                'content'    => 'text/css'
            );
            $metas[] = array(
                'http-equiv' => 'Content-Script-Type',
                'content'    => 'text/javascript'
            );
        }
        */
        
        if (!$frameset) {
            if (UA::isIPhoneGroup() || UA::isIPhoneGroup(geti($_SERVER['HTTP_USER_AGENT']))) {
                ?><link rel="apple-touch-icon" href="img/p2iphone-w.png"><?php
                
                // <meta name="viewport" content="width=device-width, initial-scale=1.0">
                // initial-scale=1.0, maximum-scale=1.0
                // initial-scale=1.0 �Ƃ���ƁA�c�����ƌ�����ς������ɁA�g�嗦���傫����ԂɂȂ��Ă��܂��B
                $metas[] = array(
                    'name'    => 'viewport',
                    'content' => 'width=device-width'
                );
                // <meta name="format-detection" content="telephone=no">
                $metas[] = array(
                    'name'    => 'format-detection',
                    'content' => 'telephone=no'
                );
                /*
                $metas[] = array(
                    'name'    => 'apple-mobile-web-app-capable',
                    'content' => 'yes'
                );
                */
            }
        }
        
        foreach ($metas as $meta) {
            $attrs = array();
            foreach ($meta as $k => $v) {
                $attrs[] = hs($k) . '="' . hs($v) . '"';
            }
            printf('<meta %s>' . "\n", implode(' ', $attrs));
        }
    }
    
    /**
     * [todo] ���͂܂��g���Ă��Ȃ��B$_conf['templateDir'] �̐ݒ�����Ă���B
     * @static
     * @access  public
     * @return  void  HTML�o��
     */
    function render($template, $params)
    {
        global $_conf;
        
        extract($params);
        require $_conf['templateDir'] . '/' . $template;
    }
}
