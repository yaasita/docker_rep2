yui-ext.js includes the entire library.

yui-ext-debug.js is the entire library uncompressed.

yui-ext-nogrid.js is the entire library except for the grid.

All other files in this directory depend on yui-ext-core.js.

editor-grid-lib.js includes everything in basic-grid-lib.js AND editing support. basic-grid-lib.js is NOT required for editor-grid-lib.js.

If you have the JS Builder, you can create your own output files using yui-ext.jsb.

