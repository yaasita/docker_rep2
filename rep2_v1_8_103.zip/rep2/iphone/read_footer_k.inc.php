<?php
/*
    p2 -  �X���b�h�\�� -  �t�b�^���� -  �g�їp for read.php
*/

//=====================================================================
// �t�b�^
//=====================================================================
// �\���͈�
$read_range_hs = _getReadRange($aThread) . '/' . $aThread->rescount;
if (!empty($_GET['onlyone'])) {
    $read_range_hs = '�v���r���[>>1';
}

// ���X�Ԏw��ړ� etc. iphone
//$goto_ht = _kspform($aThread, isset($GLOBALS['word']) ? $last_hit_resnum : $aThread->resrange['to']);

// �t�B���^�[�\�� Edit 080727 by 240
$seafrm_ht = _createFilterForm($aThread, $res_filter);
$hr = P2View::getHrHtmlK();

//=====================================================================
// HTML�o��
//=====================================================================

if (strlen($GLOBALS['word']) && !$GLOBALS['_filter_hits']) {
    ?>�q�b�g���܂���ł����B<br><?php
}

if (($aThread->rescount or !empty($_GET['onlyone']) && !$aThread->diedat)) { // and (!$_GET['renzokupop'])

    if (!$aThread->diedat) {
        if (!empty($_conf['disable_res'])) {
            $dores_ht = <<<EOP
      | <a href="{$motothre_url}" target="_blank" >{$dores_st}</a>
EOP;
        } else {
            $dores_ht = P2View::tagA(
                UriUtil::buildQueryUri('post_form_i.php',
                    array(
                        'host' => $aThread->host,
                        'bbs'  => $aThread->bbs,
                        'key'  => $aThread->key,
                        'rescount' => $aThread->rescount,
                        'ttitle_en' => $ttitle_en,
                        UA::getQueryKey() => UA::getQueryValue()
                    )
                ),
                hs($dores_st)
            );
        }
    }
    
    //iPhone �\���p�t�b�^ 080725
    //�@�O�A���A�V�� �������͍�
    if ($read_navi_latest_btm_ht) { // �ŐVN��
        $new_btm_ht = "<span id=\"newButton\" ontouchstart=\"startTap(this)\" ontouchmove=\"resetTap()\" ontouchend=\"if(detectTap(this)){ this.style.backgroundPositionY = '-50px' }\">{$read_navi_latest_btm_ht}</span>";
    }
    if ($read_footer_navi_new_btm_ht) { // �V����\��
        $new_btm_ht = "<span id=\"newButton\" ontouchstart=\"startTap(this)\" ontouchmove=\"resetTap()\" ontouchend=\"if(detectTap(this)){ this.style.backgroundPositionY = '-50px' }\">{$read_footer_navi_new_btm_ht}</span>"; 
    }
    if ($read_navi_previous_btm_ht) { 
        $read_navi_previous_tab_ht = "<span class=\"prev\">{$read_navi_previous_btm_ht} </span>";
    } else {
        $read_navi_previous_tab_ht = '<span class="prev_disabled"></span>';
    }
    if ($read_navi_next_btm_ht) {
        $read_navi_next_btm_tab_ht = "<span class=\"next\">{$read_navi_next_btm_ht}</span>";
    } else {
        $read_navi_next_btm_tab_ht = '<span class="next_disabled"></span>';
    }
    
    $index_uri = UriUtil::buildQueryUri('index.php', array(UA::getQueryKey() => UA::getQueryValue()));
    
    $goto_select_ht = _csrangeform(isset($GLOBALS['word']) ? $last_hit_resnum : $aThread->resrange['to'], $aThread, $read_range_hs);
    ?>

<?php echo P2View::getHrHtmlK(); ?>

<div id="footform">
<a id="footer" name="footer"></a>
<?php echo $goto_select_ht, $goto_next_ht; ?>
</div>

<?php
    // �������݃t�H�[���̃I�v�V�����ǂݍ���
    require_once P2_LIB_DIR . '/loadPostOptions.func.php';
    loadPostOptions($aThread->host, $aThread->bbs, $aThread->key);
    
    // �������݃t�H�[��HTML���o��
    require_once P2_LIB_DIR . '/getPostFormPopupIPhoneHtml.func.php';
    echo getPostFormPopupIPhoneHtml($aThread->host, $aThread->bbs, $aThread->key, $ttitle_en = base64_encode($aThread->ttitle), $aThread->rescount);
?>

<div id="footToolbar" class="footbar">

	<span class="home"><a href="<?php eh($index_uri); ?>">TOP</a></span>
	<?php echo $read_navi_previous_tab_ht; ?>
	<?php echo $new_btm_ht; ?>
	<span id="writeButton" title="off"><a onclick="popUpFootbarFormIPhone(1);">��������</a></span>

	<?php if (!empty($_GET['onlyone']) && !file_exists($aThread->keyidx)) {
	    ?><span class="delelog_disabled"></span><?php
	} else { 
	    ?><span class="delelog" id="readi_delelog"><?php echo _getToolDeleATag($thread_qs, $ttitle_en, $dele_st); ?></span><?php
	}

	?><span id="etcButoon" title="off"><a onclick="popUpFootbarFormIPhone(2);">���̑�</a></span>
	<?php //echo $read_navi_next_btm_tab_ht; ?>

</div>

<?php // �u���̑��v�̃|�b�v�A�b�v���j���[ ?>
<div id="footbarEtc">
<filedset>
<ul>
	<li class="whiteButton" id="searchRes" title="off" onclick="popUpFootbarFormIPhone(0);">���X����</li>
	<?php echo $toolbar_right_ht; ?> 
	<li class="grayButton" onclick="popUpFootbarFormIPhone(2,1);">�L�����Z��</li><?php // �͂ݏo�������̂��߂ɃL�����Z���{�^���͕K�v ?>
</ul>
</filedset>
</div>

<?php echo $seafrm_ht; ?>

<?php
    if ($diedat_msg_ht) {
        //echo '<hr>';
        echo $diedat_msg_ht;
        echo "<p>$motothre_atag</p>";
    }
}

//echo "<hr>" . P2View::getBackToIndexKATag() . "\n";

?>
</body></html>
<?php


// ���̃t�@�C���ł̏����͂����܂�


//==================================================================================
// �֐��i���̃t�@�C�����ł̂ݗ��p�j
//==================================================================================
function _getToolDeleATag($thread_qs, $ttitle_en, $dele_st) {
    
    global $STYLE;
    
    $sid_qs = array();
    if (defined('SID') && strlen(SID)) {
        $sid_qs[session_name()] = session_id();
    }
    $info_qs = array_merge($thread_qs, array(UA::getQueryKey() => UA::getQueryValue()), array('ttitle_en' => $ttitle_en));
    $dele_url = UriUtil::buildQueryUri('info_i.php', array_merge($info_qs, array('dele' => '1')));
    $deleLogJs_query = UriUtil::buildQuery(array_merge($info_qs, $sid_qs));
    $deleLogJs_query_es = str_replace("'", "\\'", $deleLogJs_query);
    return P2View::tagA(
        $dele_url, hs($dele_st),
        array(
            'onclick'   => "document.getElementById('readi_delelog').style.backgroundPosition = '-318px -50px'; return !deleLog('{$deleLogJs_query_es}', {$STYLE['info_pop_size']}, 'read_i_tool', this);"
        )
    );
}

/**
 * �\���ʒu���擾����
 *
 * @return  string
 */
function _getReadRange($aThread)
{
    global $_filter_range, $_filter_hits;
    
    $read_range = null;
    
    if (isset($GLOBALS['word']) && $aThread->rescount) {
        $_filter_range['end'] = min($_filter_range['to'], $_filter_hits);
        $read_range = "{$_filter_range['start']}-{$_filter_range['end']}/{$_filter_hits}hit";

    } elseif ($aThread->resrange_multi) {
        $read_range = hs($aThread->ls);

    } elseif ($aThread->resrange['start'] == $aThread->resrange['to']) {
        $read_range = $aThread->resrange['start'];

    } else {
        $read_range = "{$aThread->resrange['start']}-{$aThread->resrange['to']}";
    }
    return $read_range;
}

/**
 * ���X�ԍ����w�肵�� �ړ��E�R�s�[(+���p)�EAAS ����t�H�[���𐶐�����
 *
 * @param  string  $default  �f�t�H���g��ktool_value��value
 * @return string  HTML
 */
function _kspform($aThread, $default = '')
{
    global $_conf;

    // au��istyle���󂯕t����Bformat="4N" �Ŏw�肷��ƃ��[�U�ɂ����̓��[�h�̕ύX���s�\�ƂȂ��āA"-"�����͂ł��Ȃ��Ȃ��Ă��܂��B
    $numonly_at = ' istyle="4" mode="numeric"'; // maxlength="7"

    $form = sprintf('<form method="get" action="%s">', hs($_conf['read_php']));
    $form .= P2View::getInputHiddenKTag();

    $required_params = array('host', 'bbs', 'key');
    foreach ($required_params as $v) {
        if (!empty($_REQUEST[$v])) {
            $form .= sprintf(
                '<input type="hidden" name="%s" value="%s">',
                hs($v), hs($_REQUEST[$v])
            );
        } else {
            return '';
        }
    }
    $form .= '<input type="hidden" name="offline" value="1">';
    $form .= sprintf('<input type="hidden" name="rescount" value="%s">', hs($aThread->rescount));
    $form .= sprintf('<input type="hidden" name="ttitle_en" value="%s">', hs(base64_encode($aThread->ttitle)));

    $form .= '<select name="ktool_name">';
    $form .= '<option value="goto">GO</option>';
    $form .= '<option value="copy">��</option>';
    $form .= '<option value="copy_quote">&gt;��</option>';
    $form .= '<option value="res_quote">&gt;ڽ</option>';
    /*
    2006/03/06 aki �m�[�}��p2�ł͖��Ή�
    if ($_conf['expack.aas.enabled']) {
        $form .= '<option value="aas">AAS</option>';
        $form .= '<option value="aas_rotate">AAS*</option>';
    }
    */
    $form .= '</select>';

    $form .= sprintf(
        '<input type="text" size="3" name="ktool_value" value="%s" %s>',
        hs($default), $numonly_at
    );
    $form .= '<input type="submit" value="OK" title="OK">';

    $form .= '</form>';

    return $form;
}

/**
 * �� <a>
 *
 * @return  string  HTML
 */
function _getDoResATag($aThread, $dores_st, $motothre_url)
{
    global $_conf;
    
    $dores_atag = null;
    
    if ($_conf['disable_res']) {
        $dores_atag = P2View::tagA(
            $motothre_url,
            hs("{$_conf['k_accesskey']['res']}.{$dores_st}"),
            array(
                'target' => '_blank',
                $_conf['accesskey_for_k'] => $_conf['k_accesskey']['res']
            )
        );

    } else {
        $dores_atag = P2View::tagA(
            UriUtil::buildQueryUri(
                'post_form.php',
                array(
                    'host' => $aThread->host,
                    'bbs'  => $aThread->bbs,
                    'key'  => $aThread->key,
                    'rescount' => $aThread->rescount,
                    'ttitle_en' => base64_encode($aThread->ttitle),
                    UA::getQueryKey() => UA::getQueryValue()
                )
            ),
            hs("{$_conf['k_accesskey']['res']}.{$dores_st}"),
            array(
                $_conf['accesskey_for_k'] => $_conf['k_accesskey']['res']
            )
        );
    }
    
    return $dores_atag;
}

/**
 * �t�B���^�[�\���t�H�[�����쐬����
 * Edit 080727 by 240
 * @return string
 */
function _createFilterForm($aThread, $res_filter)
{
    global $_conf;
    
    $headbar_htm = '';
    
    // ���X�t�B���^ form HTML

    if ($aThread->rescount and empty($_GET['renzokupop'])) {

        $selected_field = array('whole' => '', 'name' => '', 'mail' => '', 'date' => '', 'id' => '', 'msg' => '');
        $selected_field[($res_filter['field'])] = ' selected';

        $selected_match = array('on' => '', 'off' => '');
        $selected_match[($res_filter['match'])] = ' selected';
    
        // �g������
        if ($_conf['enable_exfilter']) {
            $selected_method = array('and' => '', 'or' => '', 'just' => '', 'regex' => '');
            $selected_method[($res_filter['method'])] = ' selected';
            $select_method_ht = <<<EOP
	<select id="method" name="method">
		<option value="or"{$selected_method['or']}>�����ꂩ</option>
		<option value="and"{$selected_method['and']}>���ׂ�</option>
		<option value="just"{$selected_method['just']}>���̂܂�</option>
		<option value="regex"{$selected_method['regex']}>���K�\��</option>
	</select>
EOP;
        }
    
        $word_hs = hs($GLOBALS['word']);

        $headbar_htm = <<<EOP
<form id="searchForm" name="searchForm" class="dialog_filter" action="{$_conf['read_php']}" accept-charset="{$_conf['accept_charset']}" style="white-space:nowrap">
	<fieldset>
		<select id="field" name="field">
			<option value="whole"{$selected_field['whole']}>�S��</option>
			<option value="name"{$selected_field['name']}>���O</option>
			<option value="mail"{$selected_field['mail']}>���[��</option>
			<option value="date"{$selected_field['date']}>���t</option>
			<option value="id"{$selected_field['id']}>ID</option>
			<option value="msg"{$selected_field['msg']}>ү����</option>
		</select>
		{$select_method_ht}
		<select id="match" name="match">
			<option value="on"{$selected_match['on']}>�܂�</option>
			<option value="off"{$selected_match['off']}>�܂܂Ȃ�</option>
		</select>
		<br>
		<label>Word:</label>
		<input id="word" name="word" type="text" value="">
		<br>
		<input type="submit" id="s2" name="s2" value="���X����" onclick="popUpFootbarFormIPhone(0, 1)"><br><br>

		<input type="hidden" name="detect_hint" value="����">
		<input type="hidden" name="bbs" value="{$aThread->bbs}">
		<input type="hidden" name="key" value="{$aThread->key}">
		<input type="hidden" name="host" value="{$aThread->host}">
		<input type="hidden" name="ls" value="all">
		<input type="hidden" name="offline" value="1">
		<input type="hidden" name="b" value="i">
	</fieldset>
</form>
EOP;
	}

	return $headbar_htm;
}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
