<?php
require_once P2_LIB_DIR . '/index.funcs.php';

/**
 * p2 - �g�їp�C���f�b�N�X��HTML�v�����g����֐�
 *
 * @access  public
 * @return  void
 */
function index_print_k()
{
    global $_conf, $_login;

    $menuKLinkHtmls = getIndexMenuKLinkHtmls(getIndexMenuKIni());
    
    $ptitle = $_conf['p2name'] . 'iPhone';
    if (UA::isAndroidWebKit()) {
        $ptitle = $_conf['p2name'] . 'Android';
    }
    
    // ���O�C�����[�U���
    $auth_user_ht   = sprintf(
        '<p>۸޲�հ��: %s - %s</p>',
        hs($_login->user_u), date('Y/m/d (D) G:i:s') 
    );
    
    // p2���O�C���pURL
    $p2_login_url = rtrim(dirname(UriUtil::getMyUri()), '/') . '/';
    $p2_login_url_pc = UriUtil::buildQueryUri($p2_login_url,
        array(
            UA::getQueryKey() => UA::getPCQuery()
        )
    );
    $p2_login_url_k = UriUtil::buildQueryUri($p2_login_url,
        array(
            UA::getQueryKey() => UA::getMobileQuery(),
            'user' => $_login->user_u
        )
    );

    // �O��̃��O�C�����
    if ($_conf['login_log_rec'] && $_conf['last_login_log_show']) {
        if (false !== $log = P2Util::getLastAccessLog($_conf['login_log_file'])) {
            $log_hs = array_map('hs', $log);
            $htm['last_login'] = <<<EOP
<font color="#888888">
�O���۸޲ݏ�� - {$log_hs['date']}<br>
հ��:   {$log_hs['user']}<br>
IP:     {$log_hs['ip']}<br>
HOST:   {$log_hs['host']}<br>
UA:     {$log_hs['ua']}<br>
REFERER: {$log_hs['referer']}
</font>
EOP;
        }
    }
    
    // �Â��Z�b�V����ID���L���b�V������Ă��邱�Ƃ��l�����āA���[�U����t�����Ă���
    // �i���t�@�����l�����āA���Ȃ��ق��������ꍇ������̂Œ��Ӂj
    $narabikae_uri = UriUtil::buildQueryUri('edit_indexmenui.php',
        array(
            'user' => $_login->user_u,
            UA::getQueryKey() => UA::getQueryValue()
        )
    );
    
    require_once P2_LIB_DIR . '/BrdCtl.php';
    $search_form_htm = BrdCtl::getMenuKSearchFormHtml('menu_i.php');

    $body_at    = P2View::getBodyAttrK();
    $hr         = P2View::getHrHtmlK();

    $urlform_onClick_ht = <<<EOP
var url_v = document.forms['urlform'].elements['url_text'].value;
if (url_v == '') {
	alert('�������X���b�h��URL����͂��ĉ������B ��Fhttp://hibari.2ch.net/test/read.cgi/software/1306160232/');
	return false;
}
EOP;

    //=========================================================
    // �g�їp HTML�o��
    //=========================================================
    P2Util::headerNoCache();
    P2View::printDoctypeTag();
    ?>
<html>
<head>
<?php
    P2View::printExtraHeadersHtml();
?>
<script type="text/javascript"> 
<!-- 
window.onload = function() { 
setTimeout(scrollTo, 100, 0, 1); 
} 
// --> 
</script> 
<?php P2View::printStyleTagImportIuiCss(); ?>
<title><?php eh($ptitle); ?></title>
</head>
<body>
<div class="toolbar">
	<h1 class="pageTitle"><?php eh($ptitle); ?></h1>
	<a class="tbutton" href="<?php eh($narabikae_uri); ?>">����</a>
</div>
<ul id="home">
	<li class="group">���j���[</li>
<?php

P2Util::printInfoHtml();

foreach ($menuKLinkHtmls as $v) {
    ?><li><?php echo $v; ?></li><?php
}

?>

<li class="group">�X���^�C/����</li>
<?php echo $search_form_htm; ?>

<li class="group">2ch�̃X��URL�𒼐ڎw��</li>
<form id="urlform" method="GET" action="<?php eh($_conf['read_php']); ?>">
	<input id="url_text" type="text" value="" name="url" placeholder="http://hibari.2ch.net/test/read.cgi/software/1306160232/">
	<?php echo P2View::getInputHiddenKTag(); ?>
	<input type="submit" name="btnG" value="�\��" onClick="<?php echo $urlform_onClick_ht; ?>">
</form>
</ul>

<div style="padding:6px 0px 10px 0px; border-top:solid 3px #eee;"><div style="padding:0 3px;">
rep2۸޲ݗpURL�iPC�j<br>
<a href="<?php eh($p2_login_url_pc); ?>"><?php eh($p2_login_url_pc); ?></a><br>
rep2۸޲ݗpURL�i�g�сj<br>
<a href="<?php eh($p2_login_url_k); ?>"><?php eh($p2_login_url_k); ?></a><br>
</div></div>

</body>
</html>
<?php
}
/*

{$hr}
{$auth_user_ht}

{$hr}
{$htm['last_login']}
*/

//============================================================================
// �֐��i���̃t�@�C�����ł̂ݗ��p�j
//============================================================================
/**
 * ���j���[���ڂ̃����NHTML���擾����
 *
 * @access  private
 * @param   array   $menuKIni  ���j���[���� �W���ݒ�
 * @param   boolean $noLink    �����N�����Ȃ��̂Ȃ�true
 * @return  string  HTML
 */
function _getMenuKLinkHtml($code, $menuKIni, $noLink = false)
{
    global $_conf, $_login;
    
    static $accesskey_ = 0;
    
    // �����ȃR�[�h�w��Ȃ�
    if (!isset($menuKIni[$code][0]) || !isset($menuKIni[$code][1])) {
        return false;
    }

    $accesskey = ++$accesskey_;
    
    if ($_conf['index_menu_k_from1']) {
        $accesskey = $accesskey + 1;
        if ($accesskey == 10) {
            $accesskey = 0;
        }
    }
    if ($accesskey > 9) {
        $accesskey = null;
    }
    
    $href = $menuKIni[$code][0] . '&user=' . $_login->user_u . '&' . UA::getQueryKey() . '=' . UA::getQueryValue();
    $name = $menuKIni[$code][1];
    /*if (!is_null($accesskey)) {
        $name = $accesskey . '.' . $name;
    }*/

    if ($noLink) {
        $linkHtml = hs($name);
    } else {
        $accesskeyAt = is_null($accesskey) ? '' : " {$_conf['accesskey_for_k']}=\"{$accesskey}\"";
        $linkHtml = "<a href=\"" . hs($href) . '">' . hs($name) . "</a>";
    }
    
    // ���� - #.���O
    if ($code == 'res_hist') {
        $name = '�������O';
        if ($noLink) {
            $logHt = hs($name);
        } else {
            $newtime = date('gis');
            $logHt = P2View::tagA(
                UriUtil::buildQueryUri('read_res_hist.php',
                    array(
                        'nt' => $newtime,
                        UA::getQueryKey() => UA::getQueryValue()
                    )
                ),
                hs($name),
                array($_conf['accesskey_for_k'] => '#')
            );
        }
        $linkHtml .= ' </li><li>' . $logHt ;
    }
    
    return $linkHtml;
}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
