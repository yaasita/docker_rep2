<?php
// p2 -  �T�u�W�F�N�g - �g�уw�b�_�\��
// for subject.php

//===============================================================
// HTML�\���p�ϐ�
//===============================================================
$newtime = date('gis');

// {{{ �y�[�W�^�C�g������URL�ݒ�

$p2_subject_url = UriUtil::buildQueryUri($_conf['subject_php'],
    array(
        'host' => $aThreadList->host,
        'bbs'  => $aThreadList->bbs,
        UA::getQueryKey() => UA::getQueryValue()
    )
);

$ptitle_url = null;

// ���ځ[�� or �q��
if ($aThreadList->spmode == 'taborn' or $aThreadList->spmode == 'soko') {
    $ptitle_url = $p2_subject_url;
    
// �������ݗ���
} elseif ($aThreadList->spmode == 'res_hist') {
    $ptitle_url = UriUtil::buildQueryUri('read_res_hist.php', array(UA::getQueryKey() => UA::getQueryValue()));
    
// �ʏ� ��
} elseif (!$aThreadList->spmode) {
    // ���ʂȃp�^�[�� index2.html
    // match�o�^���head�Ȃ��ĕ������ق����悳���������A�������X�|���X������̂�����
    if (preg_match('/www\.onpuch\.jp/', $aThreadList->host)) {
        $ptitle_url = $ptitle_url . 'index2.html';
    } elseif (preg_match("/livesoccer\.net/", $aThreadList->host)) {
        $ptitle_url = $ptitle_url . 'index2.html';
    
    // PC
    } elseif (UA::isPC()) {
        $ptitle_url = "http://{$aThreadList->host}/{$aThreadList->bbs}/i/";
    // �g��
    } else {
        if (!empty($GLOBALS['word']) || !empty($GLOBALS['wakati_words'])) {
            $ptitle_url = $p2_subject_url;
        } else {
            if (P2Util::isHostBbsPink($aThreadList->host)) {
                $ptitle_url = "http://{$aThreadList->host}/{$aThreadList->bbs}/i/";
            } else {
                $ptitle_url = "http://c.2ch.net/test/-/{$aThreadList->bbs}/i";
            }
        }
    }
}

// }}}
// {{{ �y�[�W�^�C�g������HTML�ݒ�

$ptitle_hs = hs($aThreadList->ptitle);

if ($aThreadList->spmode == 'taborn') {
    $ptitle_ht = <<<EOP
	<a href="{$ptitle_url}"><b>{$aThreadList->itaj_hs}</b></a>�i���ݒ��j
EOP;
} elseif ($aThreadList->spmode == 'soko') {
    $ptitle_ht = <<<EOP
	<a href="{$ptitle_url}"><b>{$aThreadList->itaj_hs}</b></a>�idat�q�Ɂj
EOP;
} elseif (!empty($ptitle_url)) {
    $ptitle_ht = sprintf('<a href="%s"><b>%s</b></a>', $ptitle_url, $ptitle_hs);
} else {
    $ptitle_ht = "<b>{$ptitle_hs}</b>";
}

// }}}

// �t�H�[��
$sb_form_hidden_ht = <<<EOP
	<input type="hidden" name="detect_hint" value="����">
	<input type="hidden" name="bbs" value="{$aThreadList->bbs}">
	<input type="hidden" name="host" value="{$aThreadList->host}">
	<input type="hidden" name="spmode" value="{$aThreadList->spmode}">
EOP;
$sb_form_hidden_ht .= P2View::getInputHiddenKTag();

// �X������
if ($_conf['enable_exfilter'] == 2) {
    $selected_method = array('and' => '', 'or' => '', 'just' => '', 'regex' => '', 'similar' => '');
    $selected_method[($sb_filter['method'])] = ' selected';

    $sb_form_method_ht = <<<EOP
			<select id="method" name="method">
				<option value="and"{$selected_method['and']}>���ׂ�</option>
				<option value="or"{$selected_method['or']}>�����ꂩ</option>
				<option value="just"{$selected_method['just']}>���̂܂�</option>
				<option value="regex"{$selected_method['regex']}>���K�\��</option>
				<option value="similar"{$selected_method['similar']}>���R��</option>
			</select>\n
EOP;
}

$word_hs = hsi($GLOBALS['wakati_word'], hsi($GLOBALS['word']));
$filter_form_ht = '';
if (
    !$aThreadList->spmode
    or $aThreadList->spmode == 'palace'
    or in_array($aThreadList->spmode, array('fav', 'recent')) && geti($_REQUEST['norefresh'])
) {
    $filter_form_ht = <<<EOP
<!-- <ul><li class="group">����</li></ul> -->
<div class="panel threTitleKensaku">
<form method="GET" action="subject_i.php" accept-charset="{$_conf['accept_charset']}" class="threTitleKensaku">
	{$sb_form_hidden_ht}
	<input type="text" id="word" name="word" value="{$word_hs}" size="11">$sb_form_method_ht
	<input type="submit" name="submit_kensaku" value="����">
</form>
</div>\n
EOP;
}

// ��������
if (!empty($GLOBALS['sb_mikke_num'])) {
    $hit_ht = "<div class=\"panel\"><h2>\"{$word}\" {$GLOBALS['sb_mikke_num']}hit!</h2></div>";
} else {
    $hit_ht = '';
}


//=================================================
// �w�b�_HTML���v�����g
//=================================================
P2Util::headerNoCache();
P2View::printDoctypeTag();
?>
<html>
<head>
<?php
P2View::printExtraHeadersHtml();
P2View::printStyleTagImportIuiCss(); ?>
<script type="text/javascript" src="iphone/js/setfavjs.iphone.js?v=20061206"></script>
	<script type="text/javascript" src="js/basic.js?2012"></script>
	<script type="text/javascript" src="iphone/js/iphone.js?20140423"></script>
	<script type="text/javascript" src="iphone/js/smartpopup.iPhone.js"></script>
<script type="text/javascript"> 
<!-- 
window.onload = function() { 
	setTimeout(scrollTo, 100, 0, 1);
	initIPhoneGestures();
} 
// --> 
</script> 
<title><?php eh($aThreadList->ptitle) ?></title>
</head>
<body id="subject">

<?php $index_uri = UriUtil::buildQueryUri('index.php', array(UA::getQueryKey() => UA::getQueryValue())); ?>
<p><a id="backButton" class="tbutton" href="<?php eh($index_uri); ?>">TOP</a></p>

<div class="toolbar"><h1 class="pageTitle"><?php eh($aThreadList->ptitle) ?></h1></div>
<?php

P2Util::printInfoHtml();

echo $filter_form_ht;
echo $hit_ht;

require_once P2_LIB_DIR . '/sb_toolbar_k.funcs.php'; // getShinchakuMatomeATag()
?>
<p><?php echo getShinchakuMatomeATag($aThreadList, $shinchaku_num); ?></p>
<?php

//=======================================================================================
// �֐��i���̃t�@�C�����ł̂ݗ��p�j
//=======================================================================================

/**
 * @return  string  HTML <a>�^�O
 */
/*
function _getBackItaAtag($aThreadList)
{
    return P2View::tagA(
        UriUtil::buildQueryUri($GLOBALS['_conf']['subject_php'],
             array(
                'host' => $aThreadList->host,
                'bbs'  => $aThreadList->bbs,
                UA::getQueryKey() => UA::getQueryValue()
            )
        ),
        hs($aThreadList->itaj),
        array('class' => 'tbutton itaButton')
    );
}
*/

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
