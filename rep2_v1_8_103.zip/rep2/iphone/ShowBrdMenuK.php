<?php
/**
 * p2 - �{�[�h���j���[��HTML�\������N���X(iPhone)
 */
class ShowBrdMenuK
{
    var $cate_id = 1; // �J�e�S���[ID

    /**
     * ���j���[�J�e�S����HTML�\������ for iPhone
     *
     * @access  public
     * @return  void
     */
    function printCate($categories)
    {
        global $_conf, $list_navi_ht;

        if (!$categories) {
            return;
        }
        
        // �\��������
        if (isset($_GET['from'])) {
            $list_disp_from = intval($_GET['from']);
        } else {
            $list_disp_from = 1;
        }
        $list_disp_all_num = sizeof($categories);
        $range = $_conf['i_sb_disp_range'];
        $disp_navi = P2Util::getListNaviRange($list_disp_from, $range, $list_disp_all_num);
    
        if ($disp_navi['from'] > 1) {
            $mae_ht = <<<EOP
<li class="prev"><a href="{$_conf['menu_k_php']}?view=cate&amp;from={$disp_navi['mae_from']}&amp;nr=1{$_conf['k_at_a']}">�O</a></li>
EOP;
        } else {
            $mae_ht = '<li class="prev_disabled"></li>';
        }
        
        if ($disp_navi['end'] < $list_disp_all_num) {
            $tugi_ht = <<<EOP
<li class="next"><a href="{$_conf['menu_k_php']}?view=cate&amp;from={$disp_navi['tugi_from']}&amp;nr=1{$_conf['k_at_a']}">��</a></li>
EOP;
        } else {
            $tugi_ht = '<li class="next_disabled"></li>';
        }

        $index_ht = sprintf('<li class="home"><a href="%s">TOP</a></li>',
            UriUtil::buildQueryUri('index.php', array(UA::getQueryKey() => UA::getQueryValue()))
        );
        $list_navi_ht = '';
        //if (!$disp_navi['all_once']) {
            $list_navi_ht = <<<EOP
<div id="footToolbar" class="footbar"><ul>{$index_ht}{$mae_ht}{$tugi_ht}</ul></div>
EOP;
        //}
        
        if (UA::isIPhoneGroup()) {
            ?><ul id="home"><li class="group">�ꗗ</li><?php
        }
        foreach ($categories as $cate) {
            if ($this->cate_id >= $disp_navi['from'] and $this->cate_id <= $disp_navi['end']) {
                echo "<li><a href=\"{$_conf['menu_k_php']}?cateid={$this->cate_id}&amp;nr=1{$_conf['k_at_a']}\">{$cate->name}($cate->num)</a></li>\n"; // $this->cate_id
            }
            $this->cate_id++;
        }
        if (UA::isIPhoneGroup()) {
            ?></ul><?php
        }
    }

    /**
     * ���j���[�J�e�S���̔�HTML�\������ for �g��
     *
     * @access  public
     * @return  void
     */
    function printIta($categories)
    {
        global $_conf, $list_navi_ht;

        if (!$categories) {
            return;
        }
        
        $csrfid = P2Util::getCsrfId();
        $hr = P2View::getHrHtmlK();
        
        $list_navi_ht = '';
        
        // �\��������
        if (isset($_GET['from'])) {
            $list_disp_from = intval($_GET['from']);
        } else {
            $list_disp_from = 1;
        }
        
        foreach ($categories as $cate) {
            if ($cate->num and $this->cate_id == $_GET['cateid']) {
                
                if (!UA::isIPhoneGroup()) {
                    echo "{$cate->name}<hr>\n";
                }

                $list_disp_all_num = $cate->num;
                $range = $_conf['i_sb_disp_range'];
                $disp_navi = P2Util::getListNaviRange($list_disp_from, $range, $list_disp_all_num);
                
                if ($disp_navi['from'] > 1) {
                    $mae_ht = <<<EOP
<li class="prev"><a href="{$_conf['menu_k_php']}?cateid={$this->cate_id}&amp;from={$disp_navi['mae_from']}&amp;nr=1{$_conf['k_at_a']}">�O</a></li>
EOP;
                } else {
                    $mae_ht = '<li class="prev_disabled"></li>';
                }
                
                if ($disp_navi['end'] < $list_disp_all_num) {
                    $tugi_ht = <<<EOP
<li class="next"><a href="{$_conf['menu_k_php']}?cateid={$this->cate_id}&amp;from={$disp_navi['tugi_from']}&amp;nr=1{$_conf['k_at_a']}">��</a></li>
EOP;
                } else {
                    $tugi_ht = '<li class="next_disabled"></li>';
                }
                
                $index_ht = sprintf('<li class="home"><a href="%s">TOP</a></li>',
                    UriUtil::buildQueryUri('index.php', array(UA::getQueryKey() => UA::getQueryValue()))
                );
                //if (!$disp_navi['all_once']) {//{$disp_navi['range_st']}
                    $list_navi_ht = <<<EOP
<div id="footToolbar" class="footbar"><ul>{$index_ht}{$mae_ht}{$tugi_ht}</ul></div>
EOP;
                //}
                
                if (UA::isIPhoneGroup()) {
                    echo '<ul>';
                    echo '<li class="group">�ꗗ</li>';
                }
                
                $i = 0;
                foreach ($cate->menuitas as $mita) {
                    $i++;
                    
                    $subject_attr = array();
                    $access_num_st = '';
                    
                    if ($i <= 9) {
                        $access_num_st = "$i.";
                        $akey_at = " {$_conf['accesskey_for_k']}=\"{$i}\"";
                    } else {
                        $access_num_st = "";
                        $akey_at = "";
                    }
                    
                    // ���v�����g
                    if ($i >= $disp_navi['from'] and $i <= $disp_navi['end']) {
                        $uri = UriUtil::buildQueryUri($_SERVER['SCRIPT_NAME'], array(
                            'host'    => $mita->host,
                            'bbs'     => $mita->bbs,
                            'itaj_en' => $mita->itaj_en,
                            'setfavita' => '1',
                            'csrfid'  => $csrfid,
                            'view'    => 'favita',
                            UA::getQueryKey() => UA::getQueryValue()
                        ));
                        $add_atag = P2View::tagA($uri, '<img src="iui/icon_add.png">', array('class' => 'plus'));
                        
                        $uri = UriUtil::buildQueryUri($_conf['subject_php'], array(
                            'host'    => $mita->host,
                            'bbs'     => $mita->bbs,
                            'itaj_en' => $mita->itaj_en,
                            UA::getQueryKey() => UA::getQueryValue()
                        ));
                        $subject_atag = P2View::tagA($uri, $mita->itaj_ht, $subject_attr);
                        
                        echo '<li>' . $add_atag . ' ' . $subject_atag . "</li>\n";
                   }
                }
            
            }
            $this->cate_id++;
        }
        if (UA::isIPhoneGroup()) {
            ?></ul><?php
        }
    }

    /**
     * ������������HTML�\������ for �g��
     *
     * @access  public
     * @return  void
     */
    function printItaSearch($categories)
    {
        global $_conf;
        global $list_navi_ht;
    
        if (!$categories) {
            return;
        }
        
        // {{{ �\��������
        
        $list_disp_from = empty($_GET['from']) ? 1 : intval($_GET['from']);
        
        $list_disp_all_num = $GLOBALS['ita_mikke']['num']; //
        $range = $_conf['i_sb_disp_range'];
        $disp_navi = P2Util::getListNaviRange($list_disp_from, $range, $list_disp_all_num);
        
        $threti_q = isset($_REQUEST['threti']) ? '&amp;threti=' . hs($_REQUEST['threti']) : '';
        $detect_hint_q = 'detect_hint=' . urlencode('����');
        $word_q = '&amp;word=' . rawurlencode($GLOBALS['word']);
        
        if ($disp_navi['from'] > 1) {
            $mae_ht = <<<EOP
<li class="prev"><a href="{$_conf['menu_k_php']}?{$detect_hint_q}{$word_q}{$threti_q}&amp;from={$disp_navi['mae_from']}&amp;nr=1{$_conf['k_at_a']}">�O</a></li>
EOP;
        } else {
            $mae_ht = '<li class="prev_disabled"></li>';
        }
        
        if ($disp_navi['end'] < $list_disp_all_num) {
            $tugi_ht = <<<EOP
<li class="next"><a href="{$_conf['menu_k_php']}?{$detect_hint_q}{$word_q}{$threti_q}&amp;from={$disp_navi['tugi_from']}&amp;nr=1{$_conf['k_at_a']}">��</a></li>
EOP;
        } else {
            $tugi_ht = '<li class="next_disabled"></li>';
        }
        
        $index_ht = sprintf('<li class="home"><a href="%s">TOP</a></li>',
            UriUtil::buildQueryUri('index.php', array(UA::getQueryKey() => UA::getQueryValue()))
        );
        //if (!$disp_navi['all_once']) {//{$disp_navi['range_st']} iphone
            $list_navi_ht = <<<EOP
<div id="footToolbar" class="footbar"><ul>{$index_ht}{$mae_ht}{$tugi_ht}</ul></div>
EOP;
        //}
        
        // }}}
        
        if (UA::isIPhoneGroup()) {
            ?><ul><?php
        }
        foreach ($categories as $cate) {
            
            if ($cate->num > 0) {
                $t = false;
                foreach ($cate->menuitas as $mita) {
                    
                    $GLOBALS['menu_show_ita_num']++;
                    if ($GLOBALS['menu_show_ita_num'] >= $disp_navi['from'] and $GLOBALS['menu_show_ita_num'] <= $disp_navi['end']) {

                        if (!$t) {
                            echo "<li class=\"group\">{$cate->name}</li>\n";
                        }
                        $t = true;
                        
                        $uri = UriUtil::buildQueryUri($_conf['subject_php'], array(
                            'host' => $mita->host,
                            'bbs'  => $mita->bbs,
                            'itaj_en' => $mita->itaj_en,
                            UA::getQueryKey() => UA::getQueryValue()
                        ));
                        $atag = P2View::tagA($uri, $mita->itaj_ht);
                        
                        if (UA::isIPhoneGroup()) {
                            echo "<li>{$atag}{$threti_num_ht}</li>\n";
                        } else {
                            echo '&nbsp;' . $atag . "{$threti_num_ht}<br>\n";
                        }
                    }
                }

            }
            $this->cate_id++;
        }
        if (UA::isIPhoneGroup()) {
            ?></ul><?php
        }
    }

    /**
     * ���C�ɔ�HTML�\������ for iPhone
     *
     * @access  public
     * @return  void
     */
    function printFavItaHtml()
    {
        global $_conf;
        
        $csrfid = P2Util::getCsrfId();
        $hr = P2View::getHrHtmlK();
        
        $favitas = BrdCtl::readFavItas();
        
        if ($favitas) {
            echo '<ul id="home"><li class="group">���C�ɓ���ꗗ</li>';
            echo '<a class="tbutton" href="editfavita_i.php">�ҏW</a>';
            // echo '<ul><li><a href="editfavita.php?b=k">�ҏW</a></li><li class="group">���C�ɓ���ꗗ</li>';
            $i = 0;
            foreach ($favitas as $favita) {
                $i++;

                extract($favita); // $host, $bbs, $itaj
                
                $attr = array();
                $key_num_st = '';

                if ($i <= 9) {
                    $attr[$_conf['accesskey_for_k']] = $i;
                    $key_num_st = "$i.";
                }

                $atag = P2View::tagA(
                    UriUtil::buildQueryUri($_conf['subject_php'],
                        array(
                            'host' => $host,
                            'bbs'  => $bbs,
                            'itaj_en' => base64_encode($itaj),
                            UA::getQueryKey() => UA::getQueryValue()
                        )
                    ),
                    hs($itaj),
                    $attr
                );
                
                if (UA::isIPhoneGroup()) {
                    echo '<li>' . $atag . '</li>';
                } else {
                    echo $atag . '<br>';
                }
                
                //  [<a href="{$_SERVER['SCRIPT_NAME']}?host={$host}&amp;bbs={$bbs}&amp;setfavita=0&amp;csrfid={$csrfid}&amp;view=favita{$_conf['k_at_a']}">��</a>]

            }
            if (UA::isIPhoneGroup()) {
                ?></ul><?php
            }
        }
        
        if (!$favitas) {
            ?><p>���C�ɔ͂܂��Ȃ��悤��</p><?php
        }
    }
}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
