<?php
// p2 - �T�u�W�F�N�g - �t�b�^HTML��\������ �g��
// for subject.php

$word_qs = _getWordQs();

$allfav_atag = _getAllFavATag($aThreadList, $sb_view);

// �y�[�W�^�C�g������HTML�ݒ�
$ptitle_ht = _getPtitleHtml($aThreadList, $ptitle_url);

// {{{ �i�r HTML�ݒ�

$mae_ht = _getMaeATag($aThreadList, $disp_navi, $word_qs);

$tugi_ht = _getTugiATag($aThreadList, $disp_navi, $word_qs, $sb_disp_all_num);

if ($disp_navi['from'] == $disp_navi['end']) {
	$sb_range_on = $disp_navi['from'];
} else {
	$sb_range_on = "{$disp_navi['from']}-{$disp_navi['end']}";
}
$sb_range_st = "{$sb_range_on}/{$sb_disp_all_num} ";

$k_sb_navi_ht = '';
if (!$disp_navi['all_once']) {
    $k_sb_navi_ht = "<div>{$sb_range_st}{$mae_ht} {$tugi_ht}</div>";
}

// }}}

// dat�q��
// �X�y�V�������[�h�łȂ���΁A�܂��͂��ځ[�񃊃X�g�Ȃ�
$dat_soko_ht = _getDatSokoATag($aThreadList);

// ���ځ[�񒆂̃X���b�h
$taborn_link_atag = _getTabornLinkATag($aThreadList, $ta_num);

// �V�K�X���b�h�쐬
$buildnewthread_atag = _getBuildNewThreadATag($aThreadList);

// {{{ �\�[�g�ύX �i�V�� ���X No. �^�C�g�� �� ���΂₳ ���� �X�����ē� ���j

$sorts = array('midoku' => '�V��', 'res' => 'ڽ', 'no' => 'No.', 'title' => '����');
if ($aThreadList->spmode and $aThreadList->spmode != 'taborn' and $aThreadList->spmode != 'soko') {
    $sorts['ita'] = '��';
}
if ($_conf['sb_show_spd']) {
    $sorts['spd'] = '���΂₳';
}
if ($_conf['sb_show_ikioi']) {
    $sorts['ikioi'] = '����';
}
$sorts['bd'] = '�X�����ē�';
if ($_conf['sb_show_fav'] and $aThreadList->spmode != 'taborn') {
    $sorts['fav'] = '��';
}

$htm['change_sort'] = "<form method=\"get\" action=\"{$_conf['subject_php']}\">";
$htm['change_sort'] .= P2View::getInputHiddenKTag();
$htm['change_sort'] .= '<input type="hidden" name="norefresh" value="1">';
// spmode��
if ($aThreadList->spmode) {
    $htm['change_sort'] .= "<input type=\"hidden\" name=\"spmode\" value=\"{$aThreadList->spmode}\">";
}
// spmode�łȂ��A�܂��́Aspmode�����ځ[�� or dat�q�ɂȂ�
if (!$aThreadList->spmode || $aThreadList->spmode == "taborn" || $aThreadList->spmode == "soko") {
    $htm['change_sort'] .= "<input type=\"hidden\" name=\"host\" value=\"{$aThreadList->host}\">";
    $htm['change_sort'] .= "<input type=\"hidden\" name=\"bbs\" value=\"{$aThreadList->bbs}\">";
}

if (!empty($_REQUEST['sb_view'])) {
    $htm['change_sort'] .= sprintf('<input type="hidden" name="sb_view" value="%s">', hs($_REQUEST['sb_view']));
}

$htm['change_sort'] .= '�\�[�g:<select name="sort">';
foreach ($sorts as $k => $v) {
    $selected = '';
    if ($GLOBALS['now_sort'] == $k) {
        $selected = ' selected';
    }
    $htm['change_sort'] .= "<option value=\"{$k}\"{$selected}>{$v}</option>";
}
$htm['change_sort'] .= '</select>';
$htm['change_sort'] .= sprintf('&nbsp;<label><input type="checkbox" name="rsort" value="1"%s>�t��</label>&nbsp;', empty($_REQUEST['rsort']) ? '' : ' checked');
$htm['change_sort'] .= '<input type="submit" value="�ύX"></form>';

// }}}

// {{{ HTML�v�����g

/*
echo "<hr>";
echo $k_sb_navi_ht;

require_once P2_LIB_DIR . '/sb_toolbar_k.funcs.php'; // getShinchakuMatomeATag()
echo getShinchakuMatomeATag();
echo '<p>' . $allfav_atag . '</p>';
echo "<p>";
echo $dat_soko_ht;
echo $taborn_link_atag;
echo $buildnewthread_atag;
echo "</p>";
echo '<p>'. $htm['change_sort'] . '</p>';
//echo "<hr>";
printf('<p>%s</p>',
    P2View::tagA(
        UriUtil::buildQueryUri('index.php', array(UA::getQueryKey() => UA::getQueryValue())),
        hs('TOP'),
        array($_conf['accesskey_for_k'] => '0')
    )
);
echo '</body></html>';
*/
/*
$k_sb_navi_ht �͉��̂R�Ɠ���
{$sb_range_st}
*/

$sb_footer_tool_ht = '';
if ($buildnewthread_atag) {
    $sb_footer_tool_ht .= sprintf('<span class="build">%s</span>', $buildnewthread_atag);
}
if ($mae_ht) {
    $sb_footer_tool_ht .= sprintf('<span class="prev">%s</span>', $mae_ht);
} else {
    $sb_footer_tool_ht .= '<span class="prev_disabled"></span>';
}
if ($tugi_ht) {
    $sb_footer_tool_ht .= sprintf('<span class="next">%s</span>', $tugi_ht);
} else {
    $sb_footer_tool_ht .= '<span class="next_disabled"></span>';
}
if ($matome_ht = getShinchakuMatomeATag($aThreadList, $shinchaku_num, true)) {
    $sb_footer_tool_ht .= sprintf('<span class="matomeButton" ontouchstart="startTap(this)" ontouchmove="resetTap()" ontouchend="if(detectTap(this)){ this.style.backgroundPositionY = \'-50px\' }">%s</span>', $matome_ht);
}

// ���̑�
$toolbar_etc_ht = '';
if ($dat_soko_ht) {
    $toolbar_etc_ht .= sprintf('<li class="whiteButton">%s</span>', $dat_soko_ht);
}
if ($allfav_atag) {
    $toolbar_etc_ht .= sprintf('<li class="whiteButton">%s</span>', $allfav_atag);
}
if ($taborn_link_atag) {
    $toolbar_etc_ht .= sprintf('<li class="whiteButton">%s</span>', $taborn_link_atag);
}


?>
<?php echo $htm['change_sort']; ?> 

<div id="footToolbar" class="footbar">
	<span class="home"><a href="<?php eh($index_uri); ?>">TOP</a></span>
    <?php if ($toolbar_etc_ht) { ?>
	<span id="etcButoon" title="off"><a onclick="popUpFootbarFormIPhone(2);">���̑�</a></span>
    <?php } ?>
	<?php echo $sb_footer_tool_ht; ?>
</div>

<?php // �u���̑��v�̃|�b�v�A�b�v���j���[ ?>
<div id="footbarEtc">
<filedset>
<ul>
	<?php echo $toolbar_etc_ht; ?>
	<li class="grayButton" onclick="popUpFootbarFormIPhone(2,1);">�L�����Z��</li><?php // �͂ݏo�������̂��߂ɃL�����Z���{�^���͕K�v ?>
</ul>
</filedset>
</div>

</body></html>
<?php

// }}}


// ���̃t�@�C���ł̏����͂����܂�


//================================================================================
// �֐��i���̃t�@�C�����ł̂ݗ��p�j
//================================================================================
/**
 * @return  array
 */
function _getWordQs()
{
    $word_qs = array();
    if (!empty($GLOBALS['wakati_words'])) {
        $word_qs = array(
            'detect_hint' => '����',
            'method' => 'similar',
            'word'   => $GLOBALS['wakati_word']
        );
    } elseif (isset($GLOBALS['word'])) {
        $word_qs = array(
            'detect_hint' => '����',
            'word'   => $GLOBALS['word'],
            'method' => $GLOBALS['sb_filter']['method']
        );
    }
    return $word_qs;
}

/**
 * @return  string  <a>
 */
function _getAllFavATag($aThreadList, $sb_view)
{
    global $_conf;
    
    $allfav_atag = '';
    if ($aThreadList->spmode == 'fav' && $sb_view == 'shinchaku') {
        $uri = UriUtil::buildQueryUri($_conf['subject_php'],
            array(
                'spmode' => 'fav',
                'norefresh' => '1',
                UA::getQueryKey() => UA::getQueryValue()
            )
        );
        $allfav_atag = P2View::tagA($uri, hs("�S�Ă̂��C�ɽڂ�\��"));
    }
    return $allfav_atag;
}

/**
 * �y�[�W�^�C�g������HTML
 *
 * @return  string  HTML
 */
function _getPtitleHtml($aThreadList, $ptitle_url)
{
    global $_conf;
    
    $ptitle_ht = '';
    
    if ($aThreadList->spmode == 'taborn') {
        $ptitle_ht = P2View::tagA(
            $ptitle_url,
            sprintf('%s.<b>%s</b>',
                hs($_conf['k_accesskey']['up']), hs($aThreadList->itaj)
            ),
            array($_conf['accesskey_for_k'] => $_conf['k_accesskey']['up'])
        ) . '�i���ݒ��j';

    } elseif ($aThreadList->spmode == 'soko') {
        $ptitle_ht = P2View::tagA(
            $ptitle_url,
            sprintf('%s.<b>%s</b>',
                hs($_conf['k_accesskey']['up']), hs($aThreadList->itaj)
            ),
            array($_conf['accesskey_for_k'] => $_conf['k_accesskey']['up'])
        ) . '�idat�q�Ɂj';

    } elseif (!empty($ptitle_url)) {
        $ptitle_ht = P2View::tagA($ptitle_url, sprintf('<b>%s</b>', hs($aThreadList->ptitle)));

    } else {
        $ptitle_ht = '<b>' . hs($aThreadList->ptitle) . '</b>';
    }
    
    return $ptitle_ht;
}

/**
 * @return  string  <a>
 */
function _getTabornLinkATag($aThreadList, $ta_num)
{
    global $_conf;
    
    $taborn_link_atag = '';
    if (!empty($ta_num)) {
        $uri = UriUtil::buildQueryUri($_conf['subject_php'], array(
            'host'   => $aThreadList->host,
            'bbs'    => $aThreadList->bbs,
            'norefresh' => '1',
            'spmode' => 'taborn',
            UA::getQueryKey() => UA::getQueryValue()
        ));
        $taborn_link_atag = P2View::tagA($uri, hs("���ݒ�({$ta_num})"));
    }
    return $taborn_link_atag;
}

/**
 * @return  string  <a>
 */
function _getBuildNewThreadATag($aThreadList)
{
    $buildnewthread_atag = '';
    if (!$aThreadList->spmode and !P2Util::isHostKossoriEnq($aThreadList->host)) {
        $uri = UriUtil::buildQueryUri('post_form_i.php', array(
            'host'   => $aThreadList->host,
            'bbs'    => $aThreadList->bbs,
            'newthread' => '1',
            UA::getQueryKey() => UA::getQueryValue()
        ));
        $buildnewthread_atag = P2View::tagA($uri, hs('�ڗ���'));
    }
    return $buildnewthread_atag;
}

/**
 * �i�r �O
 *
 * @return  string  HTML
 */
function _getMaeATag($aThreadList, $disp_navi, $word_qs)
{
    global $_conf;
    
    $mae_atag = '';
    
    if ($disp_navi['from'] > 1) {
        $qs = array(
            'host'    => $aThreadList->host,
            'bbs'     => $aThreadList->bbs,
            'spmode'  => $aThreadList->spmode,
            'norefresh' => '1',
            'from'    => $disp_navi['mae_from'],
            'sb_view' => geti($_REQUEST['sb_view']),
            'rsort'   => geti($_REQUEST['rsort']),
            UA::getQueryKey() => UA::getQueryValue()
        );
        $qs = array_merge($word_qs, $qs);
        $mae_atag = P2View::tagA(
            UriUtil::buildQueryUri($_conf['subject_php'], $qs),
            hs('�O') // {$_conf['k_accesskey']['prev']}.�O
            //,array($_conf['accesskey_for_k'] => $_conf['k_accesskey']['prev'])
        );
    }
    return $mae_atag;
}

/**
 * �i�r ��
 *
 * @return  string  HTML
 */
function _getTugiATag($aThreadList, $disp_navi, $word_qs, $sb_disp_all_num)
{
    global $_conf;
    
    $tugi_atag = '';
    
    if ($disp_navi['tugi_from'] <= $sb_disp_all_num) {
        $qs = array(
            'host'    => $aThreadList->host,
            'bbs'     => $aThreadList->bbs,
            'spmode'  => $aThreadList->spmode,
            'norefresh' => '1',
            'from'    => $disp_navi['tugi_from'],
            'sb_view' => geti($_REQUEST['sb_view']),
            'rsort'   => geti($_REQUEST['rsort']),
            UA::getQueryKey() => UA::getQueryValue()
        );
        $qs = array_merge($word_qs, $qs);
        $tugi_atag = P2View::tagA(
            UriUtil::buildQueryUri($_conf['subject_php'], $qs),
            hs('��') // {$_conf['k_accesskey']['next']}.��
            //,array($_conf['accesskey_for_k'] => $_conf['k_accesskey']['next'])
        );
    }
    
    return $tugi_atag;
}

/**
 * @return  string  <a>
 */
function _getDatSokoATag($aThreadList)
{
    global $_conf;
    
    $dat_soko_atag = '';
    if (!$aThreadList->spmode or $aThreadList->spmode == 'taborn') {
        $uri = UriUtil::buildQueryUri($_conf['subject_php'], array(
            'host'   => $aThreadList->host,
            'bbs'    => $aThreadList->bbs,
            'norefresh' => '1',
            'spmode' => 'soko',
            UA::getQueryKey() => UA::getQueryValue()
        ));
        $dat_soko_atag = P2View::tagA($uri, hs('dat�q��'));
    }
    return $dat_soko_atag;
}

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
