<?php
/*
    p2 -  �X���b�h�\�� -  �w�b�_���� -  �g�їp for read.php
*/

// �ϐ�
$diedat_msg_ht = '';

$info_st        = '�X�����\��';
$dele_st        = '���O�폜';
$prev_st        = '�O';
$next_st        = '��';
$shinchaku_st   = '�V��';
$moto_thre_st   = '���X��';
$siml_thre_st   = '�ގ��X��';
$latest_st      = '�V��';
$dores_st       = '���X';
$find_st        = '����';

$motothre_url   = $aThread->getMotoThread();
$ttitle_en      = base64_encode($aThread->ttitle);
$ttitle_urlen   = rawurlencode($ttitle_en);

// ��$xxx_q �͎g��Ȃ������i�p�~�������j
$ttitle_en_q    = "&amp;ttitle_en=" . $ttitle_urlen;
$bbs_q          = "&amp;bbs=" . $aThread->bbs;
$key_q          = "&amp;key=" . $aThread->key;
$offline_q      = "&amp;offline=1";

$word_hs        = hs($GLOBALS['word']);

$thread_qs = array(
    'host' => $aThread->host,
    'bbs'  => $aThread->bbs,
    'key'  => $aThread->key
);

$newtime = date('gis');  // ���������N���N���b�N���Ă��ēǍ����Ȃ��d�l�ɑ΍R����_�~�[�N�G���[


//=================================================================
// �w�b�_HTML
//=================================================================

// ���C�Ƀ}�[�N�ݒ�
$favmark = $aThread->fav ? '<span class="fav">��</span>' : '<span class="fav">+</span>';
$favvalue = $aThread->fav ? 0 : 1;

// ���X�i�r�ݒ� =====================================================

$rnum_range = $_conf['i_rnum_range'];
$latest_show_res_num = $_conf['i_rnum_range']; // �ŐVXX

$read_navi_previous_ht     = '';
$read_navi_previous_btm_ht = '';
$read_navi_next_ht         = '';
$read_navi_next_btm_ht     = '';
$read_footer_navi_new_ht   = '';
$read_footer_navi_new_btm_ht = '';
$read_navi_latest_ht       = '';
$read_navi_latest_btm_ht   = '';
$read_navi_filter_ht       = '';
$read_navi_filter_btm_ht   = '';

$pointer_header_at = ' id="header" name="header"';

// ���X�͈̓Z���N�g�t�H�[��
//$goto_select_ht = _csrangeform(isset($GLOBALS['word']) ? $last_hit_resnum : $aThread->resrange['to'], $aThread);
$goto_select_ht = '';

//----------------------------------------------
// $htm['read_navi_range'] -- 1- 101- 201-

$htm['read_navi_range'] = '';

//080726�@�t�b�^�Ɉړ������܂�
/*
for ($i = 1; $i <= $aThread->rescount; $i = $i + $rnum_range) {
    $offline_range_q = "";
    $accesskey_at = "";
    if ($i == 1) {
        $accesskey_at = " {$_conf['accesskey_for_k']}=\"1\"";
    }
    $ito = $i + $rnum_range -1;
    if ($ito <= $aThread->gotnum) {
        $offline_range_q = $offline_q;
    }
    $htm['read_navi_range'] .= "<a class=\"blueButton\" href=\"{$_conf['read_php']}?host={$aThread->host}{$bbs_q}{$key_q}&amp;ls={$i}-{$ito}{$offline_range_q}{$_conf['k_at_a']}\">{$i}-</a>\t";
    break;    // 1-�̂ݕ\��
}
*/

//----------------------------------------------
// {{{ $read_navi_previous_ht -- �O

$before_rnum = max($aThread->resrange['start'] - $rnum_range, 1);

$read_navi_prev_isInvisible = false;
if (P2Util::ifFiltering()) {
    if ($_filter_range['start'] == 1) {
        $read_navi_prev_isInvisible = true;
    }
} else {
    if ($aThread->resrange['start'] == 1 or !empty($_GET['onlyone'])) {
        $read_navi_prev_isInvisible = true;
    }
}

$read_navi_prev_anchor = '';
//if ($before_rnum != 1) {
//    $read_navi_prev_anchor = "#r{$before_rnum}";
//}

if (!$read_navi_prev_isInvisible) {
    $q = UriUtil::buildQuery(array_merge(
        $thread_qs,
        array(
            //'ls'        => "{$before_rnum}-{$aThread->resrange['start']}n",
            'offline'   => '1',
            UA::getQueryKey() => UA::getQueryValue()
        )
    ));
    
//$html = "{$_conf['k_accesskey']['prev']}.{$prev_st}";
    $html = "{$prev_st}";
    $url = $_conf['read_php'] . '?' . $q;
    
    if ($aThread->resrange_multi and !empty($_REQUEST['page']) and $_REQUEST['page'] > 1) {
        $html = $html . '*';
       $url .= '&ls=' . $aThread->ls;
        $prev_page = intval($_REQUEST['page']) - 1;
        $url .= '&page=' . $prev_page;
    } else {
        $url .= '&ls=' . "{$before_rnum}-{$aThread->resrange['start']}n";
    }
    $read_navi_prev_header_url = $url . '&jsanc=' . "r{$aThread->resrange['start']}";
    $read_navi_previous_ht = P2View::tagA($read_navi_prev_header_url, $html, array('class' => 'tbutton buttonW', 'style' => 'right:54px', 'target' => '_self'));
    $read_navi_previous_btm_ht = P2View::tagA($url, $html, array($_conf['accesskey_for_k'] => $_conf['k_accesskey']['prev']));
}

// }}}

//----------------------------------------------
// $read_navi_next_ht -- ��
$read_navi_next_isInvisible = false;
$read_navi_next_anchor = '';
if ($aThread->resrange['to'] >= $aThread->rescount and empty($_GET['onlyone'])) {
    $aThread->resrange['to'] = $aThread->rescount;
    //$read_navi_next_anchor = "#r{$aThread->rescount}";
    if (!($aThread->resrange_multi and !empty($aThread->resrange_multi_exists_next))) {
        $read_navi_next_isInvisible = true;
    }
} else {
    // $read_navi_next_anchor = "#r{$aThread->resrange['to']}";
}
if ($aThread->resrange['to'] == $aThread->rescount) {
    //$read_navi_next_anchor = "#r{$aThread->rescount}";
}

if (!$read_navi_next_isInvisible) {
    //$read_navi_next_ht = P2View::tagA(_getNextUrl($aThread), hs($next_st));
    $read_navi_next_btm_ht = P2View::tagA(_getNextUrl($aThread), hs($next_st), array($_conf['accesskey_for_k'] => $_conf['k_accesskey']['next']));
}

// �傫�Ȏ�N�{�^��
$goto_next_ht = _getGotoNextHtml($read_navi_next_isInvisible, $aThread, $next_st, $read_navi_next_anchor);


//----------------------------------------------
// $read_footer_navi_new_ht  ������ǂ� �V�����X�̕\��
list($read_footer_navi_new_ht, $read_footer_navi_new_btm_ht) = _getReadFooterNaviNewHtmls($aThread, $shinchaku_st);


if (!$read_navi_next_isInvisible || P2Util::ifFiltering()) {

    // �ŐVN��
    $read_navi_latest_ht = <<<EOP
<a class="blueButton" href="{$_conf['read_php']}?host={$aThread->host}{$bbs_q}{$key_q}&amp;ls=l{$latest_show_res_num}n{$_conf['k_at_a']}">{$latest_st}{$latest_show_res_num}</a> 
EOP;
    $time = time();
    $read_navi_latest_btm_ht = <<<EOP
<a href="{$_conf['read_php']}?host={$aThread->host}{$bbs_q}{$key_q}&amp;ls=l{$latest_show_res_num}n&amp;dummy={$time}{$_conf['k_at_a']}">{$latest_st}{$latest_show_res_num}</a> 
EOP;
}

// {{{ ���X���������N �i���I�[�o�[���C�|�b�v�A�b�v�̕��𗘗p���Ă���j
/*
$read_navi_filter_ht = $read_navi_filter_btm_ht = P2View::tagA(
    UriUtil::buildQueryUri('read_filter_i.php',
        array(
            'host' => $aThread->host,
            'bbs'  => $aThread->bbs,
            'key'  => $aThread->key,
            'ttitle_en' => $ttitle_en,
            UA::getQueryKey() => UA::getQueryValue()
        )
    ),
    hs($find_st)
);
*/
// }}}


if (P2Util::ifFiltering()) {
    require_once P2_LIB_DIR . '/read_filter_k.funcs.php';
    rewriteReadNaviHeaderK();
}

//====================================================================
// HTML�o��
//====================================================================

// {{{ �c�[���o�[����HTML

// ���C�Ƀ}�[�N�ݒ�
$favmark    = !empty($aThread->fav) ? '��' : '+';
$favvalue   = !empty($aThread->fav) ? 0 : 1;
$favtitle   = $favvalue ? '���C�ɃX���ɒǉ�' : '���C�ɃX������O��';
$favtitle   .= '�i�A�N�Z�X�L�[[f]�j';
$setfav_q   = '&amp;setfav=' . $favvalue;

$toolbar_right_ht = _getToolbarRightHtml($aThread, $ttitle_en, $info_st, $dele_st, $moto_thre_st);

// iPhone �p�@�߂�{�^��
$toolbar_back_board_ht = sprintf("<p>%s</p>\n", _getBackItaATag($aThread));

// }}}

$body_at = '';
//$body_at = P2View::getBodyAttrK();

    //$body_at .= " onunload=\"document.frmresrange.reset()\"";
    /* iPhone �L���b�V�����̂��ߍ폜 2008/7/24 */
//=====================================
//!empty($_GET['nocache']) and P2Util::headerNoCache();
P2View::printDoctypeTag();

?>
<html>
<head>
<?php
    P2View::printExtraHeadersHtml();
    ?>
	<script type="text/javascript" src="js/basic.js?2012"></script>
	<script type="text/javascript" src="iphone/js/respopup.iPhone.js?v=20090429"></script>
	<script type="text/javascript" src="iphone/js/setfavjs.js?v=20090428"></script>
	<script type="text/javascript" src="js/post_form.js?v=20130624"></script>
	<script type="text/javascript" src="js/delelog.js?v=20130611"></script>
	<script type="text/javascript" src="iphone/js/iphone.js?20140423"></script>
	<script type="text/javascript"> 
	<!-- 
	window.onload = function() { 
		 <?php $jsanc = preg_replace('/[^a-zA-Z0-9_-]/', '', geti($_GET['jsanc'])); ?>
		if (<?php echo (int)strlen($jsanc); ?>) {
			anchorJump('<?php eh($jsanc) ?>');
		} else {
			scrollForHideIPhoneUrlMenu();
		}

		initIPhoneGestures();
        
		/* ���{�^���̉����g�� */
		expandLargeNextButton();
	}

	// ���X�͈͂̃t�H�[���̓��e�����Z�b�g���Ă���y�[�W�ڍs���郁�\�b�h
	var onArreyt = 2;
	function formReset() {
		var uriValue = "<?php echo $_conf['read_php']; ?>?"
					+ "offline=1&"
					//+ "b=" + document.frmresrange.b.value + "&"
					<?php if (UA::getQueryValue()) { ?>
					+ "<?php echo UA::getQueryKey(); ?>=<?php echo UA::getQueryValue(); ?>&"
					<?php } ?>
					+ "host=" + document.frmresrange.host.value + "&"
					+ "bbs=" + document.frmresrange.bbs.value + "&"
					+ "key=" + document.frmresrange.key.value + "&"
					+ "rescount=" + document.frmresrange.rescount.value + "&"
					+ "ttitle_en=" + document.frmresrange.ttitle_en.value + "&"
					+ "ls=" + document.frmresrange.ls.value + "&";
		//document.frmresrange.reset();
		window.location.assign(uriValue);
	}
	// --> 
	</script>

	<link rel="stylesheet" type="text/css" href="./iui/smartphone.css?20140423">
	<link rel="stylesheet" type="text/css" href="./iui/read.css?20140423">
	<title><?php echo $ptitle_ht; ?></title>
<?php


//iPhone SMP
$onload_script = '';

/*
if ($_conf['bottom_res_form']) {
    ?><script type="text/javascript" src="js/post_form.js?v=20090724"></script>
<?php
    $onload_script .= "checkSage();"; // �������݃t�H�[����sage�Ƀ`�F�b�N������
}
*/
$onload_script .= 'checkSage();';

if (empty($_GET['onlyone'])) {
    $onload_script .= "setWinTitle();";
}

$fade = empty($_GET['fade']) ? 'false' : 'true';
$existWord = strlen($GLOBALS['word']) ? 'true' : 'false';

echo <<<EOP
<script type="text/javascript">
<!--
gFade = {$fade};
gExistWord = {$existWord};
// �y�[�W���[�h�����t���O(true����Ȃ��Ƃ��C�ɓ���ύXjavascript�������Ȃ��H)
gIsPageLoaded = false;
addLoadEvent(function() { // basic.js�̃��\�b�h
	gIsPageLoaded = true;
	{$onload_script}
});
//-->
</script>\n
EOP;

// �X�}�[�g�|�b�v�A�b�v���j���[ JavaScript�R�[�h
if ($_conf['enable_spm']) {
    ?><script type="text/javascript" src="iphone/js/smartpopup.iPhone.js?v=20130606"></script><?php

    $aThread->showSmartPopUpMenuJs();
}

?>
</head>
<body id="read" <?php echo $body_at; ?>>

<?php
if (
    ($aThread->rescount or !empty($_GET['onlyone']) && !$aThread->diedat)
    and empty($_GET['renzokupop'])
) {
    // �c�[���o�[���Ȃ���TOP�����N�̕\�����������
    ?><?php $index_uri = UriUtil::buildQueryUri('index.php', array(UA::getQueryKey() => UA::getQueryValue())); ?>
    <p><a id="backButton" class="tbutton" href="<?php eh($index_uri); ?>">TOP</a></p><?php

    ?><div class="toolbar"><?php
    echo $toolbar_back_board_ht;

    //echo $htm['read_navi_range'];
    
    echo $read_navi_previous_ht;

    ?><span class="setfav"><?php echo _getFavATag($aThread, $ttitle_en, $favvalue, $favmark, $favtitle); ?></span><?php

    ?><a class="tbutton buttonW" href="javascript:window.scrollBy(0, document.documentElement.clientHeight)" target="_self">��</a>
</div>
<?php

/* iPhone �ł͏��O
<!-- {$read_navi_next_ht} -->
{$read_navi_latest_ht}
*/
}

P2Util::printInfoHtml();

// �X�����T�[�o�ɂȂ����
if ($aThread->diedat) { 

    $motothre_atag = P2View::tagA($motothre_url, hs($moto_thre_st));
    
    echo $diedat_msg_ht = _getGetDatErrorMsgHtml($aThread);
    echo "<p>$motothre_atag</p>";
    
    // �������X���Ȃ���΁A�����Ńc�[���o�[�\��
    if (!$aThread->rescount) {
        echo "<p>{$toolbar_right_ht}</p>";
    }
}


?>
<h4 class="thread_title"><?php eh($aThread->ttitle_hc); ?></h4>
<?php

//<div id="debugpanel">a</div>

$filter_fields = array(
    'whole' => '',
    'msg'   => 'ү���ނ�',
    'name'  => '���O��',
    'mail'  => 'Ұق�',
    'date'  => '���t��',
    'id'    => 'ID��',
    'belv'  => '�߲�Ă�'
);

if (isset($GLOBALS['word']) && strlen($GLOBALS['word'])) {
    ?><div><?php
    echo hs(sprintf(
        '��������: %s"%s"��%s',
        $filter_fields[$res_filter['field']],
        $GLOBALS['word'],
        ($res_filter['match'] == 'on') ? '�܂�' : '�܂܂Ȃ�'
    ));
    ?></div><?php
}

//echo P2View::getHrHtmlK();

// ���̃t�@�C�����ł̏����͂����܂�


//=======================================================================================
// �֐��i���̃t�@�C�����ł̂ݗ��p�j
//=======================================================================================

/**
 * @return  string  HTML <a>�^�O
 */
function _getBackItaATag($aThread)
{
    return P2View::tagA(
        UriUtil::buildQueryUri($GLOBALS['_conf']['subject_php'],
             array(
                'host' => $aThread->host,
                'bbs'  => $aThread->bbs,
                //'key'  => $aThread->key,
                UA::getQueryKey() => UA::getQueryValue()
            )
        ),
        hs($aThread->itaj),
        array('class' => 'tbutton itaButton')
    );
}
    
/**
 * @return  string  HTML
 */
function _getFavATag($aThread, $ttitle_en, $favvalue, $favmark, $favtitle)
{
    global $_conf, $STYLE;
    
    // ���C�ɃX���ɒǉ�/�O��
    $info_qs = array(
        'host' => $aThread->host,
        'bbs' => $aThread->bbs,
        'key' => $aThread->key,
        'ttitle_en' => $ttitle_en,
        UA::getQueryKey() => UA::getQueryValue()
    );
    $setfav_url = UriUtil::buildQueryUri('info_i.php', array_merge($info_qs, array('setfave' => $favvalue)));
    $sid_qs = (defined('SID') && strlen(SID)) ? array(session_name() => session_id()) : array();
    $setFavJs_query = UriUtil::buildQuery(array_merge($info_qs, $sid_qs));
    $setFavJs_query_es = str_replace("'", "\\'", $setFavJs_query);
    return $setFavATag = P2View::tagA(
        $setfav_url,
        hs($favmark),
        array(
            'accesskey' => $_conf['pc_accesskey']['setfav'],
            'title'     => $favtitle,
            'target'    => 'info',
            'onclick'   => "return setFavJs('{$setFavJs_query_es}', '{$favvalue}', {$STYLE['info_pop_size']}, 'read', this);",
            'class'     => 'tbutton buttonW favbutton'
        )
    );
}

/**
 * �傫�Ȏ�N�{�^���i�����N�o�[�W�����j
 * �i���̊֐��� lib/read_filter_k.funcs.php �ł����p����Ă���j
 *
 * @return  string  HTML
 */
function _getGotoNextHtml($read_navi_next_isInvisible, $aThread, $next_st, $read_navi_next_anchor = '')
{
    global $_conf;
    
    // $read_navi_next_anchor �͎g�p���Ă��Ȃ��̂ŁA�K�v������܂ŏȗ�
    
    $filter_page = isset($_REQUEST['filter_page']) ? max(1, intval($_REQUEST['filter_page'])) : 1;
    $rnum_range = $_conf['i_rnum_range'];
    $newtime = date('gis');
    
    $qs = array();
    
    if (!$read_navi_next_isInvisible) {

        // ���X������
        if (P2Util::ifFiltering()) {
            $qs = array(
                'host' => $aThread->host,
                'bbs'  => $aThread->bbs,
                'key'  => $aThread->key,
                'offline' => 1,
                UA::getQueryKey() => UA::getQueryValue(),
                
                'detect_hint' => '����',
                'word' => $GLOBALS['word'],
                'ls'   => 'all',
                'filter_page' => $filter_page + 1
            );

        } else {
            $qs = array(
                'host' => $aThread->host,
                'bbs'  => $aThread->bbs,
                'key'  => $aThread->key,
                'offline' => 1,
                UA::getQueryKey() => UA::getQueryValue(),
                
                'nt'   => $newtime
            );
        }

        $st = "{$next_st}";

        // $aThread->resrange['to'] > $aThread->resrange_readnum
        if ($aThread->resrange_multi and !empty($aThread->resrange_multi_exists_next)) {
            $st = $st . '*';

            $page = isset($_REQUEST['page']) ? max(1, intval($_REQUEST['page'])) : 1;
            $next_page = $page + 1;
            
            $qs = array_merge($qs, array(
                'ls' => $aThread->ls,
                'page' => $next_page
            ));
        
        } else {
            $after_rnum = $aThread->resrange['to'] + $rnum_range;
            $als = "{$aThread->resrange['to']}-{$after_rnum}n" . $read_navi_next_anchor;

            $qs = array_merge($qs, array(
                'ls' => $als,
                'jsanc' => 'r' . ($aThread->resrange['to'] + 1)
            ));
        }
    }
    
    if ($read_navi_next_isInvisible) {
        return sprintf('<span id="large_next">%s</span>', hs($next_st) . $rnum_range);
    }
    
    return P2View::tagA(
        UriUtil::buildQueryUri($GLOBALS['_conf']['read_php'], $qs),
        hs($st) . $rnum_range,
        array('id' => 'large_next')
    );
}

/**
 * �傫�Ȏ�N�{�^���iform�o�[�W�����j
 * �i���̊֐��� lib/read_filter_k.funcs.php �ł����p����Ă���j
 *
 * @return  string  HTML
 */
 /*
function _getGotoNextHtml($read_navi_next_isInvisible, $aThread, $next_st, $read_navi_next_anchor = '')
{
    global $_conf;
    
    // $read_navi_next_anchor �͎g�p���Ă��Ȃ��̂ŁA�K�v������܂ŏȗ�
    
    $filter_page = isset($_REQUEST['filter_page']) ? max(1, intval($_REQUEST['filter_page'])) : 1;
    $rnum_range = $_conf['i_rnum_range'];
    $newtime = date('gis');
    
    $goto_next_ht = ''; // �傫�Ȏ�N�{�^��
    $goto_next_ht = sprintf('<form style="margin-left: 1px; display:inline;" action="%s">', hs($_conf['read_php']));
    
    if (!$read_navi_next_isInvisible) {

        // ���X������
        if (P2Util::ifFiltering()) {
            $qs = array(
                'host' => $aThread->host,
                'bbs'  => $aThread->bbs,
                'key'  => $aThread->key,
                'offline' => 1,
                UA::getQueryKey() => UA::getQueryValue(),
                
                'detect_hint' => '����',
                'word' => $GLOBALS['word'],
                'ls'   => 'all',
                'filter_page' => $filter_page + 1
            );

        } else {
            $qs = array(
                'host' => $aThread->host,
                'bbs'  => $aThread->bbs,
                'key'  => $aThread->key,
                'offline' => 1,
                UA::getQueryKey() => UA::getQueryValue(),
                
                'nt'   => $newtime
            );
        }
        foreach ($qs as $k => $v) {
            $goto_next_ht .= sprintf('<input type="hidden" name="%s" value="%s">', hs($k), hs($v));
        }
        
        $goto_next_ht .= P2View::getInputHiddenKTag();

        $st = "{$next_st}";

        // $aThread->resrange['to'] > $aThread->resrange_readnum
        if ($aThread->resrange_multi and !empty($aThread->resrange_multi_exists_next)) {
            $st = $st . '*';

            $page = isset($_REQUEST['page']) ? max(1, intval($_REQUEST['page'])) : 1;
            $next_page = $page + 1;

            $goto_next_ht .= sprintf('<input type="hidden" name="ls" value="%s">', hs($aThread->ls));
            $goto_next_ht .= sprintf('<input type="hidden" name="page" value="%s">', hs($next_page));
        
        } else {
            $after_rnum = $aThread->resrange['to'] + $rnum_range;
            $als = "{$aThread->resrange['to']}-{$after_rnum}n" . $read_navi_next_anchor;

            $goto_next_ht .= sprintf('<input type="hidden" name="ls" value="%s">', hs($als));
            $goto_next_ht .= sprintf('<input type="hidden" name="jsanc" value="%s">', hs('r' . ($aThread->resrange['to'] + 1)));
        }
    }
    
    $goto_next_ht .= sprintf(
        '<input id="large_next" type="submit" value="%s"%s />',
        $read_navi_next_isInvisible ? hs($next_st) . $rnum_range : hs($st) . $rnum_range,
        $read_navi_next_isInvisible ? ' disabled' : ''
    );
    $goto_next_ht .= '</form>';
    
    return $goto_next_ht;
}
*/

/**
 * @return  string
 */
function _getNextUrl($aThread, $read_navi_next_anchor = '')
{
    global $_conf;
    
    $rnum_range = $_conf['i_rnum_range'];
    
    $url = UriUtil::buildQueryUri($_conf['read_php'],
        array(
            'host' => $aThread->host,
            'bbs'  => $aThread->bbs,
            'key'  => $aThread->key,
            //'ls'        => "{$aThread->resrange['to']}-{$after_rnum}n",
            'offline'   => '1',
            'nt'        => date('gis'),
            UA::getQueryKey() => UA::getQueryValue()
        )
    );

    //$url = $_conf['read_php'] . '?' . $q;

    // $aThread->resrange['to'] > $aThread->resrange_readnum
    if ($aThread->resrange_multi and !empty($aThread->resrange_multi_exists_next)) {
        $url .= '&ls=' . $aThread->ls; // http_build_query() ��ʂ��� urlencode ���|�������Ȃ��H
    
        $page = isset($_REQUEST['page']) ? max(1, intval($_REQUEST['page'])) : 1;
        $next_page = $page + 1;
        $url .= '&page=' . $next_page;

    } else {
        $after_rnum = $aThread->resrange['to'] + $rnum_range;
        //$als = "{$aThread->resrange['to']}-{$after_rnum}n" . $read_navi_next_anchor;
        $als = "{$aThread->resrange['to']}-{$after_rnum}n" . '&jsanc=r' . ($aThread->resrange['to'] + 1);
        $url .= '&ls=' . $als;
    }
    return $url;
}

/**
 * 1- �̂ݕ\����select�t�H�[���ŕ\������
 * �iiPhone�p�ɒǉ��j
 *
 * @return string
 */
function _csrangeform($default = '', $aThread, $read_range_hs = '')
{
    global $_conf;

    //$numonly_at = 'maxlength="4" istyle="4" format="*N" mode="numeric"';
    $numonly_at = 'maxlength="4" istyle="4" format="4N" mode="numeric"';
    
    $form = '<form method="get" name="frmresrange" id="frmresrange" style="display:inline;">';
    $form .= '<input type="hidden" name="offline" value="1">';
    $form .= P2View::getInputHiddenKTag();
    
    $required_params = array('host', 'bbs', 'key');
    foreach ($required_params as $k) {
        $form .= sprintf(
            '<input type="hidden" name="%s" value="%s">',
            hs($k), hs($aThread->$k)
        );
    }
    
    $form .= '<input type="hidden" name="rescount" value="' . hs($aThread->rescount) . '">';
    $form .= '<input type="hidden" name="ttitle_en" value="' . hs(base64_encode($aThread->ttitle)) . '">';

    $form .= sprintf('<select name="ls" action="%s" onChange="formReset()">', hs($_conf['read_php']));
    
    if (!$read_range_hs) {
        $read_range_hs = "�X�����ړ�($aThread->rescount)";
    }
    $form .= sprintf('<option disabled="disabled" selected="selected">%s</option>', $read_range_hs);
    for ($i = 1; $i <= $aThread->rescount; $i = $i + $_conf['i_rnum_range']) {
	    $offline_range_q = '';
	    $accesskey_at = '';
	    if ($i == 1) {
	        $accesskey_at = " {$_conf['accesskey_for_k']}=\"1\"";
	    }
	    $ito = $i + $_conf['i_rnum_range'] -1;
	    if ($ito <= $aThread->gotnum) {
	        $offline_range_q = '&amp;offline=1';
	    }
	    $form .= "<option value=\"{$i}-{$ito}n\">{$i}-</option>";
	}
    /*
    2006/03/06 aki �m�[�}��p2�ł͖��Ή�
    if ($_conf['expack.aas.enabled']) {
        $form .= '<option value="aas">AAS</option>';
        $form .= '<option value="aas_rotate">AAS*</option>';
    }
    */
    $form .= '</select>';
    
    $form .= '</form>';

    return $form;
}

/**
 * �V�����X�̕\�� <a>
 *
 * @return  array
 */
function _getReadFooterNaviNewHtmls($aThread, $shinchaku_st)
{
    global $_conf;
    
    $read_footer_navi_new_ht = '';
    $read_footer_navi_new_btm_ht = '';

    if ($aThread->resrange['to'] == $aThread->rescount) {
    
        // �V�����X�̕\�� <a>
        $read_footer_navi_new_uri = UriUtil::buildQueryUri(
            $_conf['read_php'],
            array(
                'host' => $aThread->host,
                'bbs'  => $aThread->bbs,
                'key'  => $aThread->key,
                'ls'   => "{$aThread->rescount}-n",
                'nt'   => date('gis'), // �L���b�V������̃_�~�[�N�G���[
                UA::getQueryKey() => UA::getQueryValue(),
                'jsanc' => 'r' . $aThread->rescount
            )
        );
        // iPhone�̃|�b�v�A�b�v�ŗ\�����ʃA���J�[�ړ������������������邽�߂ɃR�����g�A�E�g
        // . '#r' . rawurlencode($aThread->rescount);
    
        $read_footer_navi_new_ht = P2View::tagA(
            $read_footer_navi_new_uri,
            "{$shinchaku_st}"
        );
        $read_footer_navi_new_btm_ht = P2View::tagA(
            $read_footer_navi_new_uri,
            "{$shinchaku_st}"
        );
    }
    return array($read_footer_navi_new_ht, $read_footer_navi_new_btm_ht);
}

/**
 * �c�[���o�[����HTML
 *
 * @return  string  HTML
 */
function _getToolbarRightHtml($aThread, $ttitle_en, $info_st, $dele_st, $moto_thre_st)
{
    global $_conf, $motothre_url, $STYLE;
    
    $thread_qs = array(
        'host' => $aThread->host,
        'bbs'  => $aThread->bbs,
        'key'  => $aThread->key
    );
    $b_qs = array(
        UA::getQueryKey() => UA::getQueryValue()
    );

    $info_qs = array_merge($thread_qs, $b_qs, array('ttitle_en' => $ttitle_en));
    
    $info_atag = P2View::tagA(
        UriUtil::buildQueryUri('info_i.php',
            $info_qs
        ),
        hs('�X�����')
    );

    $similar_qs = array(
        'detect_hint' => '����',
        'itaj_en'     => base64_encode($aThread->itaj),
        'method'      => 'similar',
        'word'        => $aThread->ttitle_hc
        // 'refresh' => 1
    );
    $similar_atag  = P2View::tagA(
        UriUtil::buildQueryUri($_conf['subject_php'],
            array_merge($similar_qs, $thread_qs, $b_qs, array('refresh' => 1))
        ),
        hs('���X��')
    );
    
    $sid_qs = array();
    if (defined('SID') && strlen(SID)) {
        $sid_qs[session_name()] = session_id();
    }
    

    $dele_url = UriUtil::buildQueryUri('info_i.php', array_merge($info_qs, array('dele' => '1')));
    $deleLogJs_query = UriUtil::buildQuery(array_merge($info_qs, $sid_qs));
    $deleLogJs_query_es = str_replace("'", "\\'", $deleLogJs_query);

    $dele_atag = P2View::tagA(
        $dele_url,
        hs($dele_st),
        array(
            /*
            'accesskey' => $_conf['pc_accesskey']['dele'],
            'title'     => sprintf(
                "���O���폜����B�����Łu���C�ɃX���v�u�a���v������O��܂��B�i�A�N�Z�X�L�[[%s]�j",
                $_conf['pc_accesskey']['dele']
            ),
            'target'    => 'info',
            */
            'onclick'   => "return !deleLog('{$deleLogJs_query_es}', {$STYLE['info_pop_size']}, '', this);"
        )
    );

    return $toolbar_right_ht = <<<EOTOOLBAR
	<li class="whiteButton">$info_atag</li>
	<!-- <li class="whiteButton">$dele_atag</li> -->
	<li class ="whiteButton">$similar_atag</li>
	<li class="whiteButton"><a href="{$motothre_url}">{$moto_thre_st}</a></li>
EOTOOLBAR;
}

/**
 * @return  string  HTML
 */
function _getGetDatErrorMsgHtml($aThread)
{
    return strlen($aThread->getdat_error_msg_ht)
        ? $aThread->getdat_error_msg_ht 
        : $aThread->getDefaultGetDatErrorMessageHTML();
}


/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
