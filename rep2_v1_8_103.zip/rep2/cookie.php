<?php
/**
 * p2 -  �N�b�L�[�F�؏���
 */

require_once './conf/conf.inc.php';

$_login->authorize(); // ���[�U�F��


header('Location: ' . _getCookieLocationUri());

exit;


//===========================================================================
// �֐��i���̃t�@�C�����ł̂ݗ��p�j
//===========================================================================
/**
 * @return  string
 */
function _getCookieLocationUri()
{
    $qs = array(
        'check_register_cookie' => '1',
        'register_cookie'     => intval(geti($_REQUEST['register_cookie'])),
        UA::getQueryKey()   => UA::getQueryValue()
    );
    if (defined('SID') && strlen(SID)) {
        $qs[session_name()] = session_id();
    }
    return $next_uri = UriUtil::buildQueryUri('login.php', $qs);
}


/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
