<?php
// p2 -  �ݒ�Ǘ��y�[�W

require_once './conf/conf.inc.php';

$_login->authorize(); // ���[�U�F��


// �����o���p�ϐ�

$ptitle = '���O�C���Ǘ�';

if (UA::isK()) {
    $status_st      = '�ð��';
    $autho_user_st  = '�F��հ��';
    $client_host_st = '�[��ν�';
    $client_ip_st   = '�[��IP���ڽ';
    $browser_ua_st  = '��׳��UA';
    $p2error_st     = 'rep2 �װ';
    $logout_st      = '۸ޱ��';
} else {
    $status_st      = '�X�e�[�^�X';
    $autho_user_st  = '�F�؃��[�U';
    $client_host_st = '�[���z�X�g';
    $client_ip_st   = '�[��IP�A�h���X';
    $browser_ua_st  = '�u���E�UUA';
    $p2error_st     = 'rep2 �G���[';
    $logout_st      = '���O�A�E�g';
}

$login_uri = UriUtil::buildQueryUri('login.php', array(UA::getQueryKey() => UA::getQueryValue()));
$login2ch_uri = UriUtil::buildQueryUri('login2ch.php', array(UA::getQueryKey() => UA::getQueryValue()));

// p2���O�C���pURL
$p2_login_url = rtrim(dirname(UriUtil::getMyUri()), '/') . '/';
$p2_login_url_pc = UriUtil::buildQueryUri($p2_login_url,
    array(
        UA::getQueryKey() => UA::getPCQuery()
    )
);
$p2_login_url_k = UriUtil::buildQueryUri($p2_login_url,
    array(
        UA::getQueryKey() => UA::getMobileQuery(),
        'user' => $_login->user_u
    )
);
$p2_login_url_i = UriUtil::buildQueryUri($p2_login_url,
    array(
        UA::getQueryKey() => UA::getIPhoneGroupQuery()
    )
);

$body_onload = '';
if (UA::isPC()) {
    $body_onload = ' onLoad="setWinTitle();"';
}

$hr = P2View::getHrHtmlK();
$body_at = P2View::getBodyAttrK();

//=========================================================
// HTML�v�����g
//=========================================================
P2Util::headerNoCache();
P2View::printDoctypeTag();
?>
<html>
<head>
<?php
P2View::printExtraHeadersHtml();
?>
	<title><?php eh($ptitle); ?></title>
<?php
if (UA::isPC()) {
    P2View::printIncludeCssHtml('style');
    P2View::printIncludeCssHtml('setting');
    ?>
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<script type="text/javascript" src="js/basic.js?2012"></script>
<?php
}

echo <<<EOP
</head>
<body{$body_onload}{$body_at}>
EOP;

if (UA::isPC()) {
    ?><p id="pan_menu">���O�C���Ǘ�</p><?php
}

P2Util::printInfoHtml();

?><ul id="setting_menu">
	<li>
		<a href="<?php eh($login_uri); ?>">rep2���[�U�Ǘ�</a>
	</li>
	<li><a href="<?php eh($login2ch_uri); ?>">2ch���O�C���Ǘ�</a>�i�����遜�j</li>
</ul>

[<a href="./index.php?logout=1" target="_top">rep2����<?php eh($logout_st); ?>����</a>]
<?php
if (UA::isK()) {
    echo $hr;
}
?>
<?php
if (UA::isIPhoneGroup()) {
?>
<p>
rep2���O�C���pURL<br>
PC <a href="<?php eh($p2_login_url_pc); ?>" target="_top"><?php eh($p2_login_url_pc); ?></a><br>
�g�� <a href="<?php eh($p2_login_url_k); ?>" target="_top"><?php eh($p2_login_url_k); ?></a><br>
iPhone (Android) <a href="<?php eh($p2_login_url_i); ?>" target="_top"><?php eh($p2_login_url_i); ?></a>
</p>
<?php } ?>

<p id="client_status">
<?php eh($autho_user_st) ?>: <?php eh($_login->user_u) ?><br>
<?php eh($client_host_st) ?>: <?php eh(P2Util::getRemoteHost()) ?><br>
<?php eh($client_ip_st) ?>: <?php eh($_SERVER['REMOTE_ADDR']) ?><br>
<?php eh($browser_ua_st) ?>: <?php ehi($_SERVER['HTTP_USER_AGENT']) ?><br>
</p>
<?php

// �t�b�^HTML�\��
if (UA::isK()) {
    echo $hr . P2View::getBackToIndexKATag() . "\n";
}

?>
</body></html>
<?php

exit;

/*
 * Local Variables:
 * mode: php
 * coding: cp932
 * tab-width: 4
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
// vim: set syn=php fenc=cp932 ai et ts=4 sw=4 sts=4 fdm=marker:
